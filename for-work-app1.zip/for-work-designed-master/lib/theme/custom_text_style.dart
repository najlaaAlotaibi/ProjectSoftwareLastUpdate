import 'package:flutter/material.dart';

import '../core/app_export.dart';

extension on TextStyle {
  TextStyle get roboto {
    return copyWith(
      fontFamily: 'Roboto',
    );
  }

  TextStyle get playfairDisplay {
    return copyWith(
      fontFamily: 'Playfair Display',
    );
  }

  TextStyle get montserrat {
    return copyWith(
      fontFamily: 'Montserrat',
    );
  }

  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }

  TextStyle get ponnala {
    return copyWith(
      fontFamily: 'Ponnala',
    );
  }

  TextStyle get montserratAlternates {
    return copyWith(
      fontFamily: 'Montserrat Alternates',
    );
  }

  TextStyle get yaro {
    return copyWith(
      fontFamily: 'Yaro',
    );
  }
}

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.
class CustomTextStyles {
  // Body text style
  static get bodyLargeBlue700 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.blue700,
      );
  static get bodyLargeBluegray400 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.blueGray400,
      );
  static get bodyLargeGray700 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.gray700,
      );
  static get bodyLargeGray700_1 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.gray700,
      );
  static get bodyMedium15 => theme.textTheme.bodyMedium!.copyWith(
        fontSize: 15.fSize,
      );
  static get bodyMediumBlack90001 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.black90001,
      );
  static get bodyMediumBlack9000115 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.black90001,
        fontSize: 15.fSize,
      );
  static get bodyMediumBlue700 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blue700,
      );
  static get bodyMediumBluegray400 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray400,
        fontSize: 15.fSize,
      );
  static get bodyMediumBluegray40002 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray40002,
      );
  static get bodyMediumBluegray400_1 => theme.textTheme.bodyMedium!.copyWith(
        color: appTheme.blueGray400,
      );
  static get bodyMediumMontserratBlack90001 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.black90001,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodyMediumMontserratBlack9000114 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.black90001,
        fontSize: 14.fSize,
      );
  static get bodyMediumMontserratBlack9000114_1 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.black90001,
        fontSize: 14.fSize,
      );
  static get bodyMediumMontserratBlack90001Light =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.black90001,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodyMediumMontserratBluegray800 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.blueGray800,
        fontSize: 14.fSize,
      );
  static get bodyMediumMontserratBluegray900 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.blueGray900,
        fontSize: 14.fSize,
      );
  static get bodyMediumMontserratGray40002 =>
      theme.textTheme.bodyMedium!.montserrat.copyWith(
        color: appTheme.gray40002,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodyMediumPrimaryContainer => theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
      );
  static get bodyMediumPrimaryContainer15 =>
      theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 15.fSize,
      );
  static get bodyMediumPrimaryContainer15_1 =>
      theme.textTheme.bodyMedium!.copyWith(
        color: theme.colorScheme.primaryContainer,
        fontSize: 15.fSize,
      );
  static get bodySmall12 => theme.textTheme.bodySmall!.copyWith(
        fontSize: 12.fSize,
      );
  static get bodySmallBluegray40001 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueGray40001,
        fontSize: 11.fSize,
      );
  static get bodySmallBluegray40002 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueGray40002,
        fontSize: 11.fSize,
      );
  static get bodySmallMontserratBlack90001 =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: appTheme.black90001,
        fontSize: 12.fSize,
      );
  static get bodySmallMontserratBluegray800 =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: appTheme.blueGray800,
        fontSize: 12.fSize,
      );
  static get bodySmallMontserratGray40002 =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: appTheme.gray40002,
        fontSize: 12.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodySmallMontserratGray40003 =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: appTheme.gray40003,
        fontSize: 12.fSize,
      );
  static get bodySmallMontserratPrimaryContainer =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 12.fSize,
      );
  static get bodySmallMontserratSecondaryContainer =>
      theme.textTheme.bodySmall!.montserrat.copyWith(
        color: theme.colorScheme.secondaryContainer,
      );
  static get bodySmallPrimary => theme.textTheme.bodySmall!.copyWith(
        color: theme.colorScheme.primary,
      );
// Display text style
  static get displayMediumBlack90001 => theme.textTheme.displayMedium!.copyWith(
        color: appTheme.black90001,
        fontSize: 40.fSize,
        fontWeight: FontWeight.w700,
      );
  static get displayMediumMontserratPrimaryContainer =>
      theme.textTheme.displayMedium!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 40.fSize,
      );
  static get displayMediumMontserratPrimaryContainer40 =>
      theme.textTheme.displayMedium!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 40.fSize,
      );
  static get displayMediumMontserratPrimaryContainer40_1 =>
      theme.textTheme.displayMedium!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 40.fSize,
      );
// Headline text style
  static get headlineLargeBlack90001 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.black90001.withOpacity(0.2),
      );
  static get headlineLargePonnala =>
      theme.textTheme.headlineLarge!.ponnala.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get headlineLargeYaro => theme.textTheme.headlineLarge!.yaro.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get headlineMediumPrimaryContainer =>
      theme.textTheme.headlineMedium!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 27.fSize,
        fontWeight: FontWeight.w700,
      );
  static get headlineSmallBlack90001 => theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.black90001,
        fontSize: 24.fSize,
        fontWeight: FontWeight.w700,
      );
  static get headlineSmallBluegray400 =>
      theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.blueGray400,
        fontSize: 24.fSize,
      );
// Label text style
  static get labelLargeGray700 => theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray700,
      );
  static get labelLargeMontserratAlternatesBluegray5001 =>
      theme.textTheme.labelLarge!.montserratAlternates.copyWith(
        color: appTheme.blueGray5001,
        fontSize: 12.fSize,
      );
  static get labelLargeMontserratAlternatesPrimaryContainer =>
      theme.textTheme.labelLarge!.montserratAlternates.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 12.fSize,
      );
  static get labelLargeMontserratBluegray100af =>
      theme.textTheme.labelLarge!.montserrat.copyWith(
        color: appTheme.blueGray100Af,
        fontSize: 12.fSize,
        fontWeight: FontWeight.w800,
      );
  static get labelLargeMontserratPrimaryContainer =>
      theme.textTheme.labelLarge!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 12.fSize,
        fontWeight: FontWeight.w800,
      );
  static get labelLargePrimaryContainer => theme.textTheme.labelLarge!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontWeight: FontWeight.w600,
      );
  static get labelLargeSemiBold => theme.textTheme.labelLarge!.copyWith(
        fontWeight: FontWeight.w600,
      );
// Roboto text style
  static get robotoBluegray400 => TextStyle(
        color: appTheme.blueGray400,
        fontSize: 7.fSize,
        fontWeight: FontWeight.w600,
      ).roboto;
// Title text style
  static get titleLargeRoboto => theme.textTheme.titleLarge!.roboto.copyWith(
        fontSize: 22.fSize,
        fontWeight: FontWeight.w700,
      );
  static get titleMediumBluegray400 => theme.textTheme.titleMedium!.copyWith(
        color: appTheme.blueGray400,
        fontSize: 18.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleMediumBluegray400SemiBold =>
      theme.textTheme.titleMedium!.copyWith(
        color: appTheme.blueGray400,
        fontWeight: FontWeight.w600,
      );
  static get titleMediumMedium => theme.textTheme.titleMedium!.copyWith(
        fontWeight: FontWeight.w500,
      );
  static get titleMediumMedium_1 => theme.textTheme.titleMedium!.copyWith(
        fontWeight: FontWeight.w500,
      );
  static get titleMediumMontserratPrimaryContainer =>
      theme.textTheme.titleMedium!.montserrat.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontSize: 16.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleMediumOnErrorContainer =>
      theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.onErrorContainer,
        fontWeight: FontWeight.w600,
      );
  static get titleMediumPoppinsBlack900 =>
      theme.textTheme.titleMedium!.poppins.copyWith(
        color: appTheme.black900,
        fontSize: 16.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleMediumPrimaryContainer =>
      theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        fontWeight: FontWeight.w600,
      );
  static get titleMediumSemiBold => theme.textTheme.titleMedium!.copyWith(
        fontWeight: FontWeight.w600,
      );
  static get titleMediumSemiBold_1 => theme.textTheme.titleMedium!.copyWith(
        fontWeight: FontWeight.w600,
      );
  static get titleSmallBlue700 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.blue700,
      );
  static get titleSmallBluegray400 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.blueGray400,
        fontSize: 14.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleSmallGray700 => theme.textTheme.titleSmall!.copyWith(
        color: appTheme.gray700,
      );
  static get titleSmallMontserrat =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        fontSize: 14.fSize,
      );
  static get titleSmallMontserrat14 =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        fontSize: 14.fSize,
      );
  static get titleSmallMontserratBluegray800 =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        color: appTheme.blueGray800,
        fontSize: 14.fSize,
      );
  static get titleSmallMontserratDeeporange500 =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        color: appTheme.deepOrange500,
        fontSize: 14.fSize,
      );
  static get titleSmallMontserratSemiBold =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        fontSize: 14.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleSmallMontserratSemiBold14 =>
      theme.textTheme.titleSmall!.montserrat.copyWith(
        fontSize: 14.fSize,
        fontWeight: FontWeight.w600,
      );
  static get titleSmallPrimaryContainer => theme.textTheme.titleSmall!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
      );
  static get titleSmallSemiBold => theme.textTheme.titleSmall!.copyWith(
        fontSize: 14.fSize,
        fontWeight: FontWeight.w600,
      );
}
