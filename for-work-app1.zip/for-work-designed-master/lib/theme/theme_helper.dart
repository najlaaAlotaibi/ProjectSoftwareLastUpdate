import 'dart:ui';
import 'package:flutter/material.dart';
import '../core/app_export.dart';

String _appTheme = "primary";
PrimaryColors get appTheme => ThemeHelper().themeColor();
ThemeData get theme => ThemeHelper().themeData();

/// Helper class for managing themes and colors.
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ThemeHelper {
  // A map of custom color themes supported by the app
  Map<String, PrimaryColors> _supportedCustomColor = {
    'primary': PrimaryColors()
  };

// A map of color schemes supported by the app
  Map<String, ColorScheme> _supportedColorScheme = {
    'primary': ColorSchemes.primaryColorScheme
  };

  /// Changes the app theme to [_newTheme].
  void changeTheme(String _newTheme) {
    _appTheme = _newTheme;
  }

  /// Returns the primary colors for the current theme.
  PrimaryColors _getThemeColors() {
    return _supportedCustomColor[_appTheme] ?? PrimaryColors();
  }

  /// Returns the current theme data.
  ThemeData _getThemeData() {
    var colorScheme =
        _supportedColorScheme[_appTheme] ?? ColorSchemes.primaryColorScheme;
    return ThemeData(
      visualDensity: VisualDensity.standard,
      colorScheme: colorScheme,
      textTheme: TextThemes.textTheme(colorScheme),
      scaffoldBackgroundColor: colorScheme.primaryContainer.withOpacity(1),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: colorScheme.primary.withOpacity(0.91),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.zero,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.transparent,
          side: BorderSide(
            color: appTheme.black90001,
            width: 1,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.zero,
        ),
      ),
      radioTheme: RadioThemeData(
        fillColor: MaterialStateColor.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return colorScheme.primaryContainer.withOpacity(1);
          }
          return Colors.transparent;
        }),
        visualDensity: const VisualDensity(
          vertical: -4,
          horizontal: -4,
        ),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: MaterialStateColor.resolveWith((states) {
          if (states.contains(MaterialState.selected)) {
            return colorScheme.primaryContainer.withOpacity(1);
          }
          return Colors.transparent;
        }),
        side: BorderSide(
          color: appTheme.black90001,
          width: 1,
        ),
        visualDensity: const VisualDensity(
          vertical: -4,
          horizontal: -4,
        ),
      ),
      dividerTheme: DividerThemeData(
        thickness: 1,
        space: 1,
        color: appTheme.blueGray50,
      ),
    );
  }

  /// Returns the primary colors for the current theme.
  PrimaryColors themeColor() => _getThemeColors();

  /// Returns the current theme data.
  ThemeData themeData() => _getThemeData();
}

/// Class containing the supported text theme styles.
class TextThemes {
  static TextTheme textTheme(ColorScheme colorScheme) => TextTheme(
        bodyLarge: TextStyle(
          color: appTheme.black90001,
          fontSize: 17.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        bodyMedium: TextStyle(
          color: appTheme.gray700,
          fontSize: 13.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        bodySmall: TextStyle(
          color: appTheme.blueGray400,
          fontSize: 10.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        displayLarge: TextStyle(
          color: colorScheme.primaryContainer.withOpacity(1),
          fontSize: 65.fSize,
          fontFamily: 'Playfair Display',
          fontWeight: FontWeight.w800,
        ),
        displayMedium: TextStyle(
          color: appTheme.blueGray400,
          fontSize: 48.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w600,
        ),
        displaySmall: TextStyle(
          color: appTheme.black90001,
          fontSize: 34.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w700,
        ),
        headlineLarge: TextStyle(
          color: colorScheme.primaryContainer.withOpacity(1),
          fontSize: 30.fSize,
          fontFamily: 'Montserrat',
          fontWeight: FontWeight.w600,
        ),
        headlineMedium: TextStyle(
          color: appTheme.black90001,
          fontSize: 28.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        headlineSmall: TextStyle(
          color: colorScheme.primaryContainer.withOpacity(1),
          fontSize: 25.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w600,
        ),
        labelLarge: TextStyle(
          color: appTheme.black90001,
          fontSize: 13.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w500,
        ),
        labelMedium: TextStyle(
          color: appTheme.blueGray400,
          fontSize: 11.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w600,
        ),
        labelSmall: TextStyle(
          color: appTheme.blueGray400,
          fontSize: 9.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w600,
        ),
        titleLarge: TextStyle(
          color: appTheme.black90001,
          fontSize: 20.fSize,
          fontFamily: 'Montserrat',
          fontWeight: FontWeight.w400,
        ),
        titleMedium: TextStyle(
          color: appTheme.black90001,
          fontSize: 17.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w700,
        ),
        titleSmall: TextStyle(
          color: appTheme.black90001,
          fontSize: 15.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w500,
        ),
      );
}

/// Class containing the supported color schemes.
class ColorSchemes {
  static final primaryColorScheme = ColorScheme.light(
    primary: Color(0XFF3D5AF1),
    primaryContainer: Color(0X7EFFFFFF),
    secondaryContainer: Color(0XFFCF2D48),
    onErrorContainer: Color(0XFF030303),
    onPrimary: Color(0XFF060527),
    onPrimaryContainer: Color(0XFF123E7E),
  );
}

/// Class containing custom colors for a primary theme.
class PrimaryColors {
  // Black
  Color get black900 => Color(0XFF050527);
  Color get black90001 => Color(0XFF000000);
// Blue
  Color get blue200 => Color(0XFF8ED1FC);
  Color get blue700 => Color(0XFF1967D2);
// BlueGray
  Color get blueGray100 => Color(0XFFD8D8D8);
  Color get blueGray400 => Color(0XFF8A8A8F);
  Color get blueGray40001 => Color(0XFF858E99);
  Color get blueGray40002 => Color(0XFF8C8C8C);
  Color get blueGray40003 => Color(0XFF888888);
  Color get blueGray50 => Color(0XFFEFEFF4);
  Color get blueGray5001 => Color(0XFFF1F1F1);
  Color get blueGray800 => Color(0XFF286352);
  Color get blueGray900 => Color(0XFF0B2851);
// BlueGrayAf
  Color get blueGray100Af => Color(0XAFD5D3D3);
// DeepOrange
  Color get deepOrange500 => Color(0XFFF26522);
// DeepPurple
  Color get deepPurpleA200 => Color(0XFFA644FF);
// Gray
  Color get gray100 => Color(0XFFF3F3F3);
  Color get gray300 => Color(0XFFE1E1E3);
  Color get gray30001 => Color(0XFFE5E5E5);
  Color get gray30002 => Color(0XFFDADADA);
  Color get gray400 => Color(0XFFC8C7CC);
  Color get gray40001 => Color(0XFFC4C4C4);
  Color get gray40002 => Color(0XFFB4B4B4);
  Color get gray40003 => Color(0XFFBFBFBF);
  Color get gray50 => Color(0XFFF9F9F9);
  Color get gray500 => Color(0XFFA5A5A5);
  Color get gray50066 => Color(0X66A5A19F);
  Color get gray5001 => Color(0XFFF8F8F8);
  Color get gray700 => Color(0XFF666666);
  Color get gray900 => Color(0XFF112233);
// Grayf
  Color get gray1007f => Color(0X7FF0F1F6);
// Green
  Color get green400 => Color(0XFF4CD964);
  Color get green700 => Color(0XFF2D932B);
// Orange
  Color get orange500 => Color(0XFFFF9500);
// Red
  Color get red50 => Color(0XFFFEEFEF);
  Color get red500 => Color(0XFFFF2929);
  Color get redA400 => Color(0XFFFF2D55);
}
