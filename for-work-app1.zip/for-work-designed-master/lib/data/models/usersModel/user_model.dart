class UserModel {
  String? userId;
  String? name; // sign up & personal information
  String? phone; // sign up & personal information
  String? email; // sign up & personal information
  String? image; // Sign up
  String? dateOfBirth; // personal information
  String? gender; // personal information
  Map<String, dynamic>? address; // location
  Map<String, dynamic>? education; // education
  Map<String, dynamic>? experience; // experience
  Map<String, dynamic>? jobPreferences; // jobPreferences
  List<String>? interests; // Interests

  UserModel({
    this.userId,
    this.name,
    this.phone,
    this.email,
    this.image,
    this.dateOfBirth,
    this.gender,
    this.address,
    this.education,
    this.experience,
    this.jobPreferences,
    this.interests,
  });

  UserModel.fromJson(Map<dynamic, dynamic>? map) {
    if (map == null) {
      return;
    }
    userId = map['userId'];
    name = map['name'];
    phone = map['phone'];
    email = map['email'];
    image = map['image'];
    dateOfBirth = map['dateOfBirth'];
    gender = map['gender'];
    address = map['address'];
    education = map['education'];
    experience = map['experience'];
    jobPreferences = map['jobPreferences'];
    interests = List.from(map['interests']);
  }

  toJson() {
    return {
      'userId': userId,
      'name': name,
      'phone': phone,
      'email': email,
      'image': image,
      'dateOfBirth': dateOfBirth,
      'gender': gender,
      'address': address,
      'education': education,
      'experience': experience,
      'jobPreferences': jobPreferences,
      'interests': interests,
    };
  }
}
