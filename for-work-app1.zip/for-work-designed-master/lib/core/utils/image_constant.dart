// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// selections images
  static String imgBag = '$imagePath/img_bag.svg';

  static String imgLock = '$imagePath/img_lock.svg';

// Login images
  static String imgEllipse2 = '$imagePath/img_ellipse_2.png';

// Login error email images
  static String imgEllipse2104x75 = '$imagePath/img_ellipse_2_104x75.png';

// Login error password images
  static String imgEllipse21 = '$imagePath/img_ellipse_2_1.png';

// 08-Sign-Up images
  static String imgGrid = '$imagePath/img_grid.svg';

// 11-Choose-Location images
  static String imgLinkedinRedA400 = '$imagePath/img_linkedin_red_a400.svg';

  static String imgBackground = '$imagePath/img_background.svg';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  static String imgContrast = '$imagePath/img_contrast.svg';

// 13-Personal-Information images
  static String imgCalendar = '$imagePath/img_calendar.svg';

// 19-Browse-One - Container images
  static String imgNavBrowse = '$imagePath/img_nav_browse.svg';

  static String imgNavJobs = '$imagePath/img_nav_jobs.svg';

  static String imgNavMessage = '$imagePath/img_nav_message.svg';

  static String imgNavNotifications = '$imagePath/img_nav_notifications.svg';

// 19-Browse-One images
  static String imgArrowDownBlack90001 =
      '$imagePath/img_arrow_down_black_900_01.svg';

  static String imgShare = '$imagePath/img_share.svg';

  static String imgFilter = '$imagePath/img_filter.svg';

// 24-Search - Tab Container images
  static String imgClose = '$imagePath/img_close.svg';

// 26-Job-Details-One images
  static String imgArrow = '$imagePath/img_arrow.svg';

  static String imgTwitter = '$imagePath/img_twitter.svg';

  static String imgBookmarkRedA400 = '$imagePath/img_bookmark_red_a400.svg';

  static String imgLinkedinBlueGray400 =
      '$imagePath/img_linkedin_blue_gray_400.svg';

  static String imgContrastBlue700 = '$imagePath/img_contrast_blue_700.svg';

  static String imgBagBlue700 = '$imagePath/img_bag_blue_700.svg';

  static String imgTicket = '$imagePath/img_ticket.svg';

  static String imgClock = '$imagePath/img_clock.svg';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgCalendarBlue700 = '$imagePath/img_calendar_blue_700.svg';

  static String imgIconTime = '$imagePath/img_icon_time.svg';

  static String imgArrowDownBlue700 = '$imagePath/img_arrow_down_blue_700.svg';

  static String imgContrastBlue70035x35 =
      '$imagePath/img_contrast_blue_700_35x35.svg';

// 28-Company-Details images
  static String imgArrowPrimarycontainer =
      '$imagePath/img_arrow_primarycontainer.svg';

  static String imgIconMorePrimarycontainer =
      '$imagePath/img_icon_more_primarycontainer.svg';

  static String imgLinkedinPrimarycontainer =
      '$imagePath/img_linkedin_primarycontainer.svg';

  static String imgOverflowMenu = '$imagePath/img_overflow_menu.svg';

  static String imgFacebook = '$imagePath/img_facebook.svg';

  static String imgInfo = '$imagePath/img_info.svg';

  static String imgIconYoutube = '$imagePath/img_icon_youtube.svg';

  static String imgTrash = '$imagePath/img_trash.svg';

  static String imgStars = '$imagePath/img_stars.svg';

  static String imgStarsGray400 = '$imagePath/img_stars_gray_400.svg';

  static String imgStarsGray40010x32 =
      '$imagePath/img_stars_gray_400_10x32.svg';

  static String imgStarsGray40010x21 =
      '$imagePath/img_stars_gray_400_10x21.svg';

  static String imgStarsGray40010x10 =
      '$imagePath/img_stars_gray_400_10x10.svg';

  static String imgPlus = '$imagePath/img_plus.svg';

// 17-Job-Preferences images
  static String imgMaximizePrimarycontainer =
      '$imagePath/img_maximize_primarycontainer.svg';

// 23-Categories images
  static String imgComputer = '$imagePath/img_computer.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgThumbsUpPrimarycontainer =
      '$imagePath/img_thumbs_up_primarycontainer.svg';

  static String imgMaximizePrimarycontainer56x56 =
      '$imagePath/img_maximize_primarycontainer_56x56.svg';

  static String imgContrastPrimarycontainer =
      '$imagePath/img_contrast_primarycontainer.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

// 25-Filter images
  static String imgLinkedinRedA40020x16 =
      '$imagePath/img_linkedin_red_a400_20x16.svg';

  static String imgContrastBlueGray400 =
      '$imagePath/img_contrast_blue_gray_400.svg';

  static String imgGraphic = '$imagePath/img_graphic.svg';

  static String imgSignal = '$imagePath/img_signal.svg';

  static String imgSignalOrange500 = '$imagePath/img_signal_orange_500.svg';

// 29-Apply-Job images
  static String imgTwitterBlueGray400 =
      '$imagePath/img_twitter_blue_gray_400.svg';

// 30-Jobs images
  static String imgIconMoreBlueGray400 =
      '$imagePath/img_icon_more_blue_gray_400.svg';

// 32-Applied-Job-Details images
  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgMaximizeGray400 = '$imagePath/img_maximize_gray_400.svg';

// 34-Message-Details images
  static String imgUpload = '$imagePath/img_upload.svg';

  static String imgCall = '$imagePath/img_call.svg';

  static String imgGroup231 = '$imagePath/img_group_231.svg';

  static String imgBubble = '$imagePath/img_bubble.svg';

  static String imgGroup216 = '$imagePath/img_group_216.svg';

  static String imgClosePrimarycontainer24x24 =
      '$imagePath/img_close_primarycontainer_24x24.svg';

  static String imgSave = '$imagePath/img_save.svg';

// 34-Message-Details One images
  static String imgRectangle1110 = '$imagePath/img_rectangle_1110.png';

  static String imgRectangle1 = '$imagePath/img_rectangle_1.png';

  static String imgTelevisionGray30002 =
      '$imagePath/img_television_gray_300_02.svg';

  static String imgSettingsOnprimary = '$imagePath/img_settings_onprimary.svg';

  static String imgMusic = '$imagePath/img_music.svg';

  static String imgUploadBlack900 = '$imagePath/img_upload_black_900.svg';

  static String imgApple131 = '$imagePath/img_apple13_1.svg';

// Common images
  static String imgIphoneStatusCopy = '$imagePath/img_iphone_status_copy.png';

  static String imgJobHuntingRemovebgPreview =
      '$imagePath/img_job_hunting_removebg_preview.png';

  static String imgIphoneStatus31 = '$imagePath/img_iphone_status3_1.png';

  static String imgEmail51 = '$imagePath/img_email_5_1.svg';

  static String imgEye1 = '$imagePath/img_eye_1.svg';

  static String imgGoogle11 = '$imagePath/img_google_1_1.svg';

  static String imgLockBlack90001 = '$imagePath/img_lock_black_900_01.svg';

  static String imgInfo21 = '$imagePath/img_info_2_1.svg';

  static String imgLinkedin = '$imagePath/img_linkedin.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgMaximize = '$imagePath/img_maximize.svg';

  static String imgArrowdown = '$imagePath/img_arrowdown.svg';

  static String imgBookmarkPrimarycontainer =
      '$imagePath/img_bookmark_primarycontainer.svg';

  static String imgBookmark = '$imagePath/img_bookmark.svg';

  static String imgLinkedinGray400 = '$imagePath/img_linkedin_gray_400.svg';

  static String imgBookmarkGreen700 = '$imagePath/img_bookmark_green_700.svg';

  static String imgIconMore = '$imagePath/img_icon_more.svg';

  static String imgArrowRightBlueGray400 =
      '$imagePath/img_arrow_right_blue_gray_400.svg';

  static String imgBackgroundPrimarycontainer =
      '$imagePath/img_background_primarycontainer.svg';

  static String imgClosePrimarycontainer =
      '$imagePath/img_close_primarycontainer.svg';

  static String imgFilterBlack90001 = '$imagePath/img_filter_black_900_01.svg';

  static String imgSearchBlack90001 = '$imagePath/img_search_black_900_01.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
