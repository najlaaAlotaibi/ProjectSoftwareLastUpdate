import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:for_work_application1/core/services/firestore_user.dart';
import 'package:for_work_application1/data/models/usersModel/user_model.dart';
import 'package:for_work_application1/presentation/browse_one_container_screen/browse_one_container_screen.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

class AuthViewModel extends GetxController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // final LocalStorageData localStorageData = Get.find();
  String countryKey = '+965'; // +965 Kw
  // var shownPassword = true.obs;
  var rememberMe = false.obs;
  var action = false.obs;
  String email = '', password = '', name = '';
  String phone = '';
  String userId = '';
  var isVerified = false.obs;
  var agreeTerms = false.obs;
  Connectivity connectivity = Connectivity();

  // This method to change Password from visible to un_visible
  // void changeShownPassword() {
  //   shownPassword.value = !shownPassword.value;
  // }

  void changeAgree() {
    agreeTerms.value = !agreeTerms.value;
  }

  void changeMemberMe() {
    rememberMe.value = !rememberMe.value;
  }

  // Method to sign with email and password
  void signInWithEmailAndPassword() async {
    action.value = true;

    try {
      await _auth
          .signInWithEmailAndPassword(
        email: email,
        password: password,
      )
          .then((value) async {
        Get.offAll(() => BrowseOneContainerScreen());
        Get.snackbar(
          'Successfully',
          'Your Information is correct',
          snackPosition: SnackPosition.TOP,
          colorText: Colors.green,
        );
        // AppConstants.loginId = value.user!.uid;
        /*
        if (await FireStoreUser().checkUser(value.user!.uid)) {
          // AppConstants.userId = value.user!.uid;
          UserModel? userData;
          await FireStoreUser().getCurrentUser(value.user!.uid).then((value) {
            userData =
                UserModel.fromJson(value.data() as Map<dynamic, dynamic>?);
          }).whenComplete(() async {
            action.value = false;
            Get.to(() => BrowseOneContainerScreen());
          });
        } 
        */
      });
    } catch (e) {
      action.value = false;
      print(e.toString());
      Get.snackbar(
        'Error Login',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        colorText: Colors.red,
      );
    }
  }

  Future<void> createAccountWithEmailAndPassword() async {
    action.value = true;
    try {
      action.value = true;
      await _auth
          .createUserWithEmailAndPassword(
        email: email,
        password: password,
      )
          .then((user) async {
        userId = user.user!.uid;
        UserModel userModel = UserModel(
          userId: userId,
          email: email,
          phone: '$countryKey$phone',
          name: name,
          image: '',
          //dateOfBirth: '',
          // address: {
          //   'Latitude': latitude.value,
          //   'Longitude': longitude.value,
          // },
          // isVerified: user.user!.emailVerified,
        );
        await FireStoreUser().addUserToFirestore(userModel).then((value) {
          action.value = false;
          Get.snackbar(
            'Successfully',
            'Create User Successfully',
            snackPosition: SnackPosition.TOP,
            colorText: Colors.green,
          );
        });

        action.value = false;
        // await user.user!.sendEmailVerification();
        return user;
      });
    } catch (e) {
      action.value = false;
      Get.snackbar(
        'Error Register',
        e.toString(),
      );
    }
  }

  String emailPasswordReset = '';

  void forgetPassword() async {
    await _auth.sendPasswordResetEmail(email: emailPasswordReset);
  }

  // Map Controller
  LocationData? locationData;
  var markers = RxSet<Marker>();
  var isLoading = false.obs;
  var longitude = 0.0.obs;
  var latitude = 0.0.obs;

  fetchLocation() async {
    try {
      isLoading(true);
      locationData = await getLocationData();
      longitude.value = locationData!.longitude!;
      latitude.value = locationData!.latitude!;
    } catch (e) {
      Get.snackbar(
        'Error while getting data',
        e.toString(),
        snackPosition: SnackPosition.TOP,
        colorText: Colors.red,
      );
    } finally {
      isLoading(false);
      createMarkers();
    }
  }

  createMarkers() {
    markers.add(
      Marker(
        markerId: const MarkerId('Location'),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        position: LatLng(latitude.value, longitude.value),
        onTap: () {},
      ),
    );
  }

  getLocationData() async {
    Location location = Location();
    bool serviceEnabled;
    PermissionStatus permissionGranted;
    LocationData locationData;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (serviceEnabled) {
        return;
      }
    }
    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted != PermissionStatus.granted) {
        return;
      }
    }
    locationData = await location.getLocation();
    return locationData;
  }
}
