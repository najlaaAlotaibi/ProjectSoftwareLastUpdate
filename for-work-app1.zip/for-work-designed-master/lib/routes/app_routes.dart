import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';
import '../presentation/applied_job_details_screen/applied_job_details_screen.dart';
import '../presentation/apply_job_screen/apply_job_screen.dart';
import '../presentation/browse_one_container_screen/browse_one_container_screen.dart';
import '../presentation/categories_screen/categories_screen.dart';
import '../presentation/choose_location_screen/choose_location_screen.dart';
import '../presentation/company_details_screen/company_details_screen.dart';
import '../presentation/education_screen/education_screen.dart';
import '../presentation/experience_screen/experience_screen.dart';
import '../presentation/filter_screen/filter_screen.dart';
import '../presentation/get_started_screen/get_started_screen.dart';
import '../presentation/job_details_one_screen/job_details_one_screen.dart';
import '../presentation/job_preferences_screen/job_preferences_screen.dart';
import '../presentation/location_screen/location_screen.dart';
import '../presentation/login_error_email_screen/login_error_email_screen.dart';
import '../presentation/login_error_password_screen/login_error_password_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/message_details_one_screen/message_details_one_screen.dart';
import '../presentation/message_details_screen/message_details_screen.dart';
import '../presentation/personal_information_screen/personal_information_screen.dart';
import '../presentation/search_tab_container_screen/search_tab_container_screen.dart';
import '../presentation/selections_screen/selections_screen.dart';
import '../presentation/set_location_screen/set_location_screen.dart';
import '../presentation/sign_up_screen/sign_up_screen.dart';
import '../presentation/splash_screen/splash_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String splashScreen = '/splash_screen';

  static const String getStartedScreen = '/get_started_screen';

  static const String selectionsScreen = '/selections_screen';

  static const String loginScreen = '/login_screen';

  static const String loginErrorEmailScreen = '/login_error_email_screen';

  static const String loginErrorPasswordScreen = '/login_error_password_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String setLocationScreen = '/set_location_screen';

  static const String chooseLocationScreen = '/choose_location_screen';

  static const String personalInformationScreen =
      '/personal_information_screen';

  static const String browseOneContainerScreen = '/browse_one_container_screen';

  static const String browseOnePage = '/browse_one_page';

  static const String searchPage = '/search_page';

  static const String searchTabContainerScreen = '/search_tab_container_screen';

  static const String jobDetailsOneScreen = '/job_details_one_screen';

  static const String companyDetailsScreen = '/company_details_screen';

  static const String locationScreen = '/location_screen';

  static const String educationScreen = '/education_screen';

  static const String experienceScreen = '/experience_screen';

  static const String jobPreferencesScreen = '/job_preferences_screen';

  static const String categoriesScreen = '/categories_screen';

  static const String filterScreen = '/filter_screen';

  static const String applyJobScreen = '/apply_job_screen';

  static const String jobsPage = '/jobs_page';

  static const String jobsTabContainerPage = '/jobs_tab_container_page';

  static const String savedPage = '/saved_page';

  static const String appliedJobDetailsScreen = '/applied_job_details_screen';

  static const String messagesPage = '/messages_page';

  static const String messageDetailsScreen = '/message_details_screen';

  static const String messageDetailsOneScreen = '/message_details_one_screen';

  static const String notificationsPage = '/notifications_page';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    splashScreen: (context) => SplashScreen(),
    getStartedScreen: (context) => GetStartedScreen(),
    selectionsScreen: (context) => SelectionsScreen(),
    loginScreen: (context) => LoginScreen(),
    loginErrorEmailScreen: (context) => LoginErrorEmailScreen(),
    loginErrorPasswordScreen: (context) => LoginErrorPasswordScreen(),
    signUpScreen: (context) => SignUpScreen(),
    setLocationScreen: (context) => SetLocationScreen(),
    chooseLocationScreen: (context) => ChooseLocationScreen(),
    personalInformationScreen: (context) => PersonalInformationScreen(),
    browseOneContainerScreen: (context) => BrowseOneContainerScreen(),
    searchTabContainerScreen: (context) => SearchTabContainerScreen(),
    jobDetailsOneScreen: (context) => JobDetailsOneScreen(),
    companyDetailsScreen: (context) => CompanyDetailsScreen(),
    locationScreen: (context) => LocationScreen(),
    educationScreen: (context) => EducationScreen(),
    experienceScreen: (context) => ExperienceScreen(),
    jobPreferencesScreen: (context) => JobPreferencesScreen(),
    categoriesScreen: (context) => CategoriesScreen(),
    filterScreen: (context) => FilterScreen(),
    applyJobScreen: (context) => ApplyJobScreen(),
    appliedJobDetailsScreen: (context) => AppliedJobDetailsScreen(),
    messageDetailsScreen: (context) => MessageDetailsScreen(),
    messageDetailsOneScreen: (context) => MessageDetailsOneScreen(),
    appNavigationScreen: (context) => AppNavigationScreen(),
    initialRoute: (context) => SplashScreen()
  };
}
