import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import 'widgets/chipviewproblem_item_widget.dart';

class AppliedJobDetailsScreen extends StatelessWidget {
  const AppliedJobDetailsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildColumnArrowLeft(context),
              SizedBox(height: 29.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Text(
                            "Track Application",
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                        SizedBox(height: 18.v),
                        Container(
                          height: 290.v,
                          width: 188.h,
                          margin: EdgeInsets.only(left: 16.h),
                          child: Stack(
                            alignment: Alignment.bottomLeft,
                            children: [
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 12.h),
                                  child: SizedBox(
                                    height: 266.v,
                                    child: VerticalDivider(
                                      width: 1.h,
                                      thickness: 1.v,
                                    ),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    right: 164.h,
                                    bottom: 34.v,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      CustomIconButton(
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        padding: EdgeInsets.all(6.h),
                                        decoration:
                                            IconButtonStyleHelper.fillGreen,
                                        child: CustomImageView(
                                          imagePath: ImageConstant.imgCheckmark,
                                        ),
                                      ),
                                      SizedBox(height: 34.v),
                                      CustomIconButton(
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        padding: EdgeInsets.all(6.h),
                                        decoration:
                                            IconButtonStyleHelper.fillGreen,
                                        child: CustomImageView(
                                          imagePath: ImageConstant.imgCheckmark,
                                        ),
                                      ),
                                      SizedBox(height: 34.v),
                                      CustomIconButton(
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        padding: EdgeInsets.all(6.h),
                                        decoration:
                                            IconButtonStyleHelper.fillGreen,
                                        child: CustomImageView(
                                          imagePath: ImageConstant.imgCheckmark,
                                        ),
                                      ),
                                      SizedBox(height: 34.v),
                                      Container(
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        decoration: BoxDecoration(
                                          color: theme
                                              .colorScheme.primaryContainer
                                              .withOpacity(1),
                                          borderRadius: BorderRadius.circular(
                                            12.h,
                                          ),
                                          border: Border.all(
                                            color: appTheme.blueGray100,
                                            width: 1.h,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(bottom: 16.v),
                                      child: CustomIconButton(
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        padding: EdgeInsets.all(6.h),
                                        decoration:
                                            IconButtonStyleHelper.fillGreen,
                                        child: CustomImageView(
                                          imagePath: ImageConstant.imgCheckmark,
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        left: 16.h,
                                        top: 3.v,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Application submitted",
                                            style: theme.textTheme.titleSmall,
                                          ),
                                          SizedBox(height: 2.v),
                                          Text(
                                            "09/23/2024 8:00",
                                            style: theme.textTheme.bodyMedium,
                                          )
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Align(
                                alignment: Alignment.bottomRight,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    left: 40.h,
                                    right: 26.h,
                                    bottom: 17.v,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Reviewed by team",
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      SizedBox(height: 2.v),
                                      Text(
                                        "09/24/2024 9:00",
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                      SizedBox(height: 19.v),
                                      Text(
                                        "Round 1 interview",
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      SizedBox(height: 4.v),
                                      Text(
                                        "09/25/2024 10:00",
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                      SizedBox(height: 19.v),
                                      Text(
                                        "Round 2 interview",
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      SizedBox(height: 4.v),
                                      Text(
                                        "09/26/2024 10:00",
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                      SizedBox(height: 19.v),
                                      Text(
                                        "Final HR interview",
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      SizedBox(height: 4.v),
                                      Text(
                                        "09/27/2024 10:00",
                                        style: theme.textTheme.bodyMedium,
                                      )
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomIconButton(
                                height: 24.adaptSize,
                                width: 24.adaptSize,
                                padding: EdgeInsets.all(7.h),
                                decoration:
                                    IconButtonStyleHelper.outlineBlueGrayTL12,
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgMaximizeGray400,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 16.h,
                                  top: 2.v,
                                  bottom: 3.v,
                                ),
                                child: Text(
                                  "Offer letter",
                                  style: theme.textTheme.titleSmall,
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 29.v),
                        _buildStackIrvineCa(context),
                        Divider(
                          indent: 16.h,
                        ),
                        SizedBox(height: 27.v),
                        _buildJobSkills(context)
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnArrowLeft(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 11.v),
      decoration: AppDecoration.fillGray50,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomAppBar(
            height: 22.v,
            leadingWidth: 21.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgArrowLeft,
              margin: EdgeInsets.only(
                left: 9.h,
                bottom: 1.v,
              ),
              onTap: () {
                onTapArrowleftone(context);
              },
            ),
            centerTitle: true,
            title: AppbarSubtitleTwo(
              text: "Applied Job Details",
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgIconMore,
                margin: EdgeInsets.fromLTRB(16.h, 8.v, 16.h, 9.v),
              )
            ],
          ),
          SizedBox(height: 18.v),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 16.h),
            padding: EdgeInsets.all(15.h),
            decoration: AppDecoration.outlineBluegray501.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder8,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: 45.adaptSize,
                  padding: EdgeInsets.symmetric(
                    horizontal: 9.h,
                    vertical: 16.v,
                  ),
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder22,
                  ),
                  child: Text(
                    "45 x 45",
                    style: theme.textTheme.labelSmall,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 4.v,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Product Designer",
                        style: theme.textTheme.titleSmall,
                      ),
                      SizedBox(height: 2.v),
                      SizedBox(
                        width: 190.h,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(bottom: 1.v),
                              child: Text(
                                "Limited Sounds",
                                style: theme.textTheme.bodyMedium,
                              ),
                            ),
                            Container(
                              height: 2.adaptSize,
                              width: 2.adaptSize,
                              margin: EdgeInsets.only(
                                top: 7.v,
                                bottom: 8.v,
                              ),
                              decoration: BoxDecoration(
                                color: appTheme.blueGray400,
                                borderRadius: BorderRadius.circular(
                                  1.h,
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: 2.v),
                              child: Text(
                                "Qurtubah , KW",
                                style: theme.textTheme.bodyMedium,
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          SizedBox(height: 5.v)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnHighlight(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Highlights",
          style: theme.textTheme.titleMedium,
        ),
        SizedBox(height: 10.v),
        Container(
          width: 163.h,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 11.v,
          ),
          decoration: AppDecoration.fillGray50,
          child: Text(
            "Location",
            style: CustomTextStyles.bodyLargeGray700_1,
          ),
        ),
        SizedBox(height: 1.v),
        Container(
          width: 163.h,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 10.v,
          ),
          decoration: AppDecoration.fillGray50,
          child: Text(
            "Experience",
            style: CustomTextStyles.bodyLargeGray700_1,
          ),
        ),
        SizedBox(height: 1.v),
        Container(
          width: 163.h,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 10.v,
          ),
          decoration: AppDecoration.fillGray50,
          child: Text(
            "Salary",
            style: CustomTextStyles.bodyLargeGray700_1,
          ),
        ),
        SizedBox(height: 1.v),
        Container(
          width: 163.h,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 10.v,
          ),
          decoration: AppDecoration.fillGray50,
          child: Text(
            "Job Type",
            style: CustomTextStyles.bodyLargeGray700_1,
          ),
        ),
        SizedBox(height: 1.v),
        Container(
          width: 163.h,
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 11.v,
          ),
          decoration: AppDecoration.fillGray50,
          child: Text(
            "Job Title",
            style: CustomTextStyles.bodyLargeGray700_1,
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildStackIrvineCa(BuildContext context) {
    return Container(
      height: 254.v,
      width: 359.h,
      margin: EdgeInsets.only(left: 16.h),
      child: Stack(
        alignment: Alignment.centerLeft,
        children: [
          Align(
            alignment: Alignment.center,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Padding(
                  padding: EdgeInsets.only(right: 72.h),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "Qurtubah",
                          style: theme.textTheme.bodyLarge,
                        ),
                        TextSpan(
                          text: " , KW",
                          style: theme.textTheme.bodyLarge,
                        )
                      ],
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
                SizedBox(height: 11.v),
                Divider(),
                SizedBox(height: 44.v),
                Divider(),
                SizedBox(height: 12.v),
                Padding(
                  padding: EdgeInsets.only(right: 25.h),
                  child: Text(
                    "500 KD - 750 KD/mo",
                    style: theme.textTheme.bodyLarge,
                  ),
                ),
                SizedBox(height: 11.v),
                Divider(),
                SizedBox(height: 44.v),
                Divider()
              ],
            ),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Row(
              children: [
                _buildColumnHighlight(context),
                Padding(
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 89.v,
                    bottom: 10.v,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "2+ years",
                        style: theme.textTheme.bodyLarge,
                      ),
                      SizedBox(height: 68.v),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Full Time",
                          style: theme.textTheme.bodyLarge,
                        ),
                      ),
                      SizedBox(height: 27.v),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Manager",
                          style: theme.textTheme.bodyLarge,
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildJobSkills(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Job Skills",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 20.v),
          Wrap(
            runSpacing: 8.v,
            spacing: 8.h,
            children: List<Widget>.generate(
                7, (index) => ChipviewproblemItemWidget()),
          )
        ],
      ),
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
