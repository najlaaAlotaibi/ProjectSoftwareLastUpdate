import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_five.dart';
import '../../widgets/app_bar/appbar_subtitle_four.dart';
import '../../widgets/app_bar/appbar_subtitle_three.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class MessageDetailsScreen extends StatelessWidget {
  MessageDetailsScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 16.v),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 269.h,
                  margin: EdgeInsets.only(
                    left: 90.h,
                    right: 16.h,
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.h,
                    vertical: 7.v,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: fs.Svg(
                        ImageConstant.imgGroup231,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Container(
                    width: 177.h,
                    margin: EdgeInsets.only(right: 67.h),
                    child: Text(
                      "Hi, We have read Your cv\nYou have an interview here \n Good luck",
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.bodyMediumPrimaryContainer15
                          .copyWith(
                        height: 1.33,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 16.h),
                  child: Text(
                    "10:11 AM",
                    style: CustomTextStyles.bodySmallBluegray40001,
                  ),
                ),
              ),
              SizedBox(height: 16.v),
              CustomElevatedButton(
                height: 34.v,
                width: 61.h,
                text: "Sure!",
                margin: EdgeInsets.only(left: 21.h),
                buttonStyle: CustomButtonStyles.fillBlueGrayTL17,
                buttonTextStyle: CustomTextStyles.bodyMediumBlack9000115,
              ),
              SizedBox(height: 2.v),
              Padding(
                padding: EdgeInsets.only(left: 17.h),
                child: _buildStackBubble(
                  context,
                  text: "Thank you in advance",
                ),
              ),
              SizedBox(height: 3.v),
              Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Text(
                  "11:23 AM",
                  style: CustomTextStyles.bodySmallBluegray40001,
                ),
              ),
              SizedBox(height: 16.v),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 177.h,
                  margin: EdgeInsets.only(right: 15.h),
                  padding: EdgeInsets.symmetric(
                    horizontal: 30.h,
                    vertical: 7.v,
                  ),
                  decoration: AppDecoration.fillBlue700.copyWith(
                    borderRadius: BorderRadiusStyle.circleBorder16,
                  ),
                  child: Text(
                    "22/1/2024",
                    style: CustomTextStyles.bodyMediumPrimaryContainer15,
                  ),
                ),
              ),
              SizedBox(height: 9.v),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 269.h,
                  margin: EdgeInsets.only(
                    left: 102.h,
                    right: 4.h,
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.h,
                    vertical: 8.v,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: fs.Svg(
                        ImageConstant.imgGroup216,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 18.v),
                      Container(
                        width: 233.h,
                        margin: EdgeInsets.only(right: 11.h),
                        child: Text(
                          "We  can’t the interview schedule be changed for any reasons",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.bodyMediumPrimaryContainer15
                              .copyWith(
                            height: 1.33,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 4.h),
                  child: Text(
                    "11:35 AM",
                    style: CustomTextStyles.bodySmallBluegray40001,
                  ),
                ),
              ),
              SizedBox(height: 9.v),
              Container(
                height: 33.v,
                width: 210.h,
                margin: EdgeInsets.only(left: 17.h),
                child: Stack(
                  alignment: Alignment.bottomLeft,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgBubble,
                      height: 33.v,
                      width: 210.h,
                      alignment: Alignment.center,
                    ),
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 15.h,
                          bottom: 7.v,
                        ),
                        child: Text(
                          "No problem",
                          style: CustomTextStyles.bodyMediumBlack9000115,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 3.v),
              Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Text(
                  "11:42 AM",
                  style: CustomTextStyles.bodySmallBluegray40001,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Text(
                  "22/1/2024",
                  style: CustomTextStyles.bodySmallBluegray40001,
                ),
              ),
              SizedBox(height: 12.v),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: 269.h,
                  margin: EdgeInsets.only(left: 106.h),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.h,
                    vertical: 8.v,
                  ),
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: fs.Svg(
                        ImageConstant.imgGroup216,
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 9.v),
                      Container(
                        width: 219.h,
                        margin: EdgeInsets.only(right: 25.h),
                        child: Text(
                          "Hi , As our interview is scheduled today , it will be in 10 min. ",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.bodyMediumPrimaryContainer15
                              .copyWith(
                            height: 1.33,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 6.v),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  "10:00 AM",
                  style: CustomTextStyles.bodySmallBluegray40001,
                ),
              ),
              SizedBox(height: 18.v),
              Padding(
                padding: EdgeInsets.only(left: 17.h),
                child: _buildStackBubble(
                  context,
                  text: "Hello , of course i’m waiting.",
                ),
              ),
              SizedBox(height: 3.v),
              Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Text(
                  "10:05 AM",
                  style: CustomTextStyles.bodySmallBluegray40001,
                ),
              ),
              SizedBox(height: 5.v)
            ],
          ),
        ),
        bottomNavigationBar: _buildRowcloseone(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 12.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 16.h),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.circleBorder16,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(height: 11.v),
                      AppbarSubtitleFive(
                        text: "32 x 32",
                        margin: EdgeInsets.symmetric(horizontal: 6.h),
                      ),
                      SizedBox(height: 3.v),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          height: 8.adaptSize,
                          width: 8.adaptSize,
                          margin: EdgeInsets.only(left: 24.h),
                          decoration: BoxDecoration(
                            color: appTheme.green400,
                            borderRadius: BorderRadius.circular(
                              4.h,
                            ),
                            border: Border.all(
                              color: theme.colorScheme.primaryContainer
                                  .withOpacity(1),
                              width: 1.h,
                              strokeAlign: BorderSide.strokeAlignOutside,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 8.h),
                  child: Column(
                    children: [
                      AppbarSubtitleThree(
                        text: "Ahmed Mohamad",
                      ),
                      SizedBox(height: 1.v),
                      AppbarSubtitleFour(
                        text: "Active now",
                        margin: EdgeInsets.only(right: 66.h),
                      )
                    ],
                  ),
                )
              ],
            )
          ],
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgUpload,
          margin: EdgeInsets.fromLTRB(16.h, 16.v, 12.h, 4.v),
          onTap: () {
            onTapUploadone(context);
          },
        ),
        AppbarTrailingImage(
          imagePath: ImageConstant.imgCall,
          margin: EdgeInsets.only(
            left: 16.h,
            top: 12.v,
            right: 28.h,
          ),
          onTap: () {
            onTapCallone(context);
          },
        )
      ],
      styleType: Style.bgShadow,
    );
  }

  /// Section Widget
  Widget _buildRowcloseone(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 16.h,
        right: 16.h,
        bottom: 38.v,
      ),
      decoration: AppDecoration.outlineBluegray502,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 6.v),
            child: CustomIconButton(
              height: 24.adaptSize,
              width: 24.adaptSize,
              padding: EdgeInsets.all(5.h),
              decoration: IconButtonStyleHelper.fillBlueTL10,
              child: CustomImageView(
                imagePath: ImageConstant.imgClosePrimarycontainer24x24,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 8.h),
              child: CustomTextFormField(
                controller: commentController,
                hintText: "Write a comment",
                hintStyle: CustomTextStyles.bodyLargeBluegray400,
                textInputAction: TextInputAction.done,
                contentPadding: EdgeInsets.all(8.h),
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgSave,
            height: 24.adaptSize,
            width: 24.adaptSize,
            margin: EdgeInsets.only(
              left: 8.h,
              top: 6.v,
              bottom: 6.v,
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildStackBubble(
    BuildContext context, {
    required String text,
  }) {
    return SizedBox(
      height: 33.v,
      width: 254.h,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBubble,
            height: 33.v,
            width: 254.h,
            alignment: Alignment.center,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(bottom: 7.v),
              child: Text(
                text,
                style: CustomTextStyles.bodyMediumBlack9000115.copyWith(
                  color: appTheme.black90001,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the messageDetailsOneScreen when the action is triggered.
  onTapUploadone(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.messageDetailsOneScreen);
  }

  /// Navigates to the messageDetailsOneScreen when the action is triggered.
  onTapCallone(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.messageDetailsOneScreen);
  }
}
