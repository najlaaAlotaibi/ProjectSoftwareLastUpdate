import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:for_work_application1/core/view_model/auth_view_model.dart';
import 'package:get/get.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';

class LoginScreen extends GetWidget<AuthViewModel> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.blue200,
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  children: [
                    _buildStackIphoneStatus(context),
                    SizedBox(height: 13.v),
                    Text(
                      "Sign in to your account",
                      style: theme.textTheme.titleLarge,
                    ),
                    SizedBox(height: 23.v),
                    _buildColumnEmail(context),
                    SizedBox(height: 19.v),
                    _buildColumnPassword(context),
                    SizedBox(height: 10.v),
                    _buildRowRememberMe(context),
                    SizedBox(height: 30.v),
                    GetX<AuthViewModel>(
                      builder: (process) => process.action.value
                          ? const Center(
                              child: CupertinoActivityIndicator(),
                            )
                          : _buildSignInButton(context),
                    ),
                    SizedBox(height: 20.v),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            top: 6.v,
                            bottom: 10.v,
                          ),
                          child: SizedBox(
                            width: 60.h,
                            child: Divider(
                              color: appTheme.gray40001,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 27.h),
                          child: Text(
                            "or",
                            style: CustomTextStyles
                                .bodyMediumMontserratBlack9000114,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            top: 6.v,
                            bottom: 10.v,
                          ),
                          child: SizedBox(
                            width: 86.h,
                            child: Divider(
                              color: appTheme.gray40001,
                              indent: 26.h,
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 12.v),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 48.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildFacebookButton(context),
                          _buildGoogleButton(context)
                        ],
                      ),
                    ),
                    SizedBox(height: 18.v),
                    GestureDetector(
                      onTap: () {
                        onTapTxtDonthaveaaccount(context);
                      },
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Don’t have a account? ",
                              style: CustomTextStyles
                                  .bodyMediumMontserratBlack9000114_1,
                            ),
                            TextSpan(
                              text: "Register",
                              style: CustomTextStyles
                                  .bodyMediumMontserratBluegray900,
                            )
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    SizedBox(height: 5.v)
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildSignInAsButton(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildStackIphoneStatus(BuildContext context) {
    return SizedBox(
      height: 213.v,
      width: 357.h,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgEllipse2,
            height: 104.v,
            width: 75.h,
            alignment: Alignment.topLeft,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgJobHuntingRemovebgPreview,
            height: 175.v,
            width: 273.h,
            alignment: Alignment.bottomCenter,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnEmail(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 17.h),
      padding: EdgeInsets.symmetric(horizontal: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 33.h),
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "Email ",
                    style: CustomTextStyles.titleSmallMontserrat,
                  ),
                  TextSpan(
                    text: "*",
                    style: CustomTextStyles.titleSmallMontserratDeeporange500,
                  )
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          SizedBox(height: 5.v),
          Padding(
            padding: EdgeInsets.only(left: 17.h),
            child: CustomTextFormField(
              onSaved: (value) {
                controller.email = value!;
              },
              hintText: "Email *",
              hintStyle: CustomTextStyles.bodySmallMontserratGray40002,
              textInputType: TextInputType.emailAddress,
              suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 19.v, 16.h, 19.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgEmail51,
                  height: 16.adaptSize,
                  width: 16.adaptSize,
                ),
              ),
              suffixConstraints: BoxConstraints(
                maxHeight: 54.v,
              ),
              contentPadding: EdgeInsets.only(
                left: 20.h,
                top: 19.v,
                bottom: 19.v,
              ),
              borderDecoration: TextFormFieldStyleHelper.fillGrayF,
              fillColor: appTheme.gray1007f,
              validator: (value) {
                final regex = RegExp(
                    r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
                if (controller.email.isEmpty) {
                  return 'Please, Enter your Email';
                } else if (!regex.hasMatch(value!)) {
                  return 'Your Email is not valid';
                }
                return null;
              },
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnPassword(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 17.h),
      padding: EdgeInsets.symmetric(horizontal: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 33.h),
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "Password",
                    style: CustomTextStyles.titleSmallMontserrat,
                  ),
                  TextSpan(
                    text: "*",
                    style: CustomTextStyles.titleSmallMontserratDeeporange500,
                  )
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          SizedBox(height: 5.v),
          Padding(
            padding: EdgeInsets.only(left: 17.h),
            child: CustomTextFormField(
              onSaved: (value) {
                controller.password = value!;
              },
              hintText: "Password",
              hintStyle: CustomTextStyles.bodySmallMontserratGray40002,
              textInputAction: TextInputAction.done,
              textInputType: TextInputType.visiblePassword,
              suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 21.v, 12.h, 9.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgEye1,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                ),
              ),
              suffixConstraints: BoxConstraints(
                maxHeight: 54.v,
              ),
              obscureText: true,
              contentPadding: EdgeInsets.only(
                left: 21.h,
                top: 19.v,
                bottom: 19.v,
              ),
              borderDecoration: TextFormFieldStyleHelper.fillGrayF,
              fillColor: appTheme.gray1007f,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowRememberMe(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 27.h,
        right: 17.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 1.v),
            child: GetX<AuthViewModel>(
              builder: (authCtrl) {
                return CustomCheckboxButton(
                  text: "Remember me",
                  value: authCtrl.rememberMe.value,
                  onChange: (value) {
                    authCtrl.changeMemberMe();
                  },
                );
              },
            ),
          ),
          Text(
            "Forgot your Password?",
            style: CustomTextStyles.bodySmallMontserratBluegray800,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSignInButton(BuildContext context) {
    return CustomElevatedButton(
      height: 52.v,
      text: "Sign In",
      margin: EdgeInsets.only(
        left: 20.h,
        right: 17.h,
      ),
      buttonStyle: CustomButtonStyles.fillPrimaryTL7,
      buttonTextStyle: CustomTextStyles.titleMediumMontserratPrimaryContainer,
      onPressed: () {
        _formKey.currentState!.save();
        if (_formKey.currentState!.validate()) {
          controller.signInWithEmailAndPassword();
        }
      },
    );
  }

  /// Section Widget
  Widget _buildFacebookButton(BuildContext context) {
    return CustomOutlinedButton(
      height: 37.v,
      width: 131.h,
      text: "Facebook",
      buttonStyle: CustomButtonStyles.outlineOnPrimaryContainer,
      buttonTextStyle: CustomTextStyles.bodySmallMontserratPrimaryContainer,
    );
  }

  /// Section Widget
  Widget _buildGoogleButton(BuildContext context) {
    return CustomElevatedButton(
      height: 37.v,
      width: 131.h,
      text: "Google",
      margin: EdgeInsets.only(left: 16.h),
      leftIcon: Container(
        margin: EdgeInsets.only(right: 7.h),
        child: CustomImageView(
          imagePath: ImageConstant.imgGoogle11,
          height: 12.adaptSize,
          width: 12.adaptSize,
        ),
      ),
      buttonStyle: CustomButtonStyles.fillGray,
      buttonTextStyle: CustomTextStyles.bodySmallMontserratGray40003,
    );
  }

  /// Section Widget
  Widget _buildSignInAsButton(BuildContext context) {
    return CustomOutlinedButton(
      height: 23.v,
      width: 147.h,
      text: "sign in as guest",
      margin: EdgeInsets.only(
        left: 117.h,
        right: 111.h,
        bottom: 23.v,
      ),
      leftIcon: Container(
        margin: EdgeInsets.only(right: 2.h),
        child: CustomImageView(
          imagePath: ImageConstant.imgLockBlack90001,
          height: 18.v,
          width: 19.h,
        ),
      ),
      buttonTextStyle: CustomTextStyles.bodyMediumMontserratBlack9000114,
      onPressed: () {
        onTapSignInAsButton(context);
      },
    );
  }

  /// Navigates to the signUpScreen when the action is triggered.
  onTapTxtDonthaveaaccount(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }

  /// Navigates to the browseOneContainerScreen when the action is triggered.
  onTapSignInAsButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.browseOneContainerScreen);
  }
}
