import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../jobs_page/jobs_page.dart';
import '../saved_page/saved_page.dart'; // ignore_for_file: must_be_immutable

class JobsTabContainerPage extends StatefulWidget {
  const JobsTabContainerPage({Key? key})
      : super(
          key: key,
        );

  @override
  JobsTabContainerPageState createState() => JobsTabContainerPageState();
}
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class JobsTabContainerPageState extends State<JobsTabContainerPage>
    with TickerProviderStateMixin {
  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray50,
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillGray50,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildColumnFilter(context),
                Column(
                  children: [
                    _buildTabview(context),
                    SizedBox(
                      height: 545.v,
                      child: TabBarView(
                        controller: tabviewController,
                        children: [JobsPage(), SavedPage()],
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnFilter(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 9.v),
      decoration: AppDecoration.fillBlue200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 2.v),
          CustomAppBar(
            height: 19.v,
            leadingWidth: 36.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgFilterBlack90001,
              margin: EdgeInsets.only(
                left: 16.h,
                top: 2.v,
                bottom: 1.v,
              ),
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgSearchBlack90001,
                margin: EdgeInsets.symmetric(horizontal: 16.h),
              )
            ],
          ),
          SizedBox(height: 15.v),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Text(
              "Jobs",
              style: theme.textTheme.displaySmall,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTabview(BuildContext context) {
    return Container(
      height: 44.v,
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        boxShadow: [
          BoxShadow(
            color: appTheme.blueGray50,
            spreadRadius: 2.h,
            blurRadius: 2.h,
            offset: Offset(
              0,
              1,
            ),
          )
        ],
      ),
      child: TabBar(
        controller: tabviewController,
        labelPadding: EdgeInsets.zero,
        labelColor: appTheme.black90001,
        labelStyle: TextStyle(
          fontSize: 15.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w500,
        ),
        unselectedLabelColor: appTheme.blueGray400,
        unselectedLabelStyle: TextStyle(
          fontSize: 15.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        indicatorColor: appTheme.blue700,
        tabs: [
          Tab(
            child: Text(
              "Applied",
            ),
          ),
          Tab(
            child: Text(
              "Saved",
            ),
          )
        ],
      ),
    );
  }
}
