import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class UserprofilesectionItemWidget extends StatelessWidget {
  const UserprofilesectionItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 11.v),
          padding: EdgeInsets.all(2.h),
          decoration: AppDecoration.fillGray.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder22,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 15.v),
              Text(
                "45 x 45",
                style: theme.textTheme.labelSmall,
              ),
              SizedBox(height: 6.v),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  height: 8.adaptSize,
                  width: 8.adaptSize,
                  decoration: BoxDecoration(
                    color: appTheme.green400,
                    borderRadius: BorderRadius.circular(
                      4.h,
                    ),
                    border: Border.all(
                      color: theme.colorScheme.primaryContainer.withOpacity(1),
                      width: 1.h,
                      strokeAlign: BorderSide.strokeAlignOutside,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            top: 4.v,
            bottom: 15.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Brave Studio",
                style: theme.textTheme.titleSmall,
              ),
              SizedBox(height: 1.v),
              Text(
                "Good luck and take care",
                style: CustomTextStyles.bodyMediumBluegray40002,
              )
            ],
          ),
        ),
        Spacer(),
        Padding(
          padding: EdgeInsets.only(
            top: 5.v,
            right: 15.h,
            bottom: 11.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(right: 1.h),
                child: Text(
                  "11:20 AM",
                  style: CustomTextStyles.bodyMediumBluegray40002,
                ),
              ),
              SizedBox(height: 3.v),
              Container(
                width: 20.adaptSize,
                padding: EdgeInsets.symmetric(
                  horizontal: 6.h,
                  vertical: 1.v,
                ),
                decoration: AppDecoration.fillBlue700.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder8,
                ),
                child: Text(
                  "3",
                  style: CustomTextStyles.bodyMediumPrimaryContainer,
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
