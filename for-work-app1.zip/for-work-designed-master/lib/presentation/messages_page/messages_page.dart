import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'widgets/userprofilesection_item_widget.dart'; // ignore_for_file: must_be_immutable

class MessagesPage extends StatelessWidget {
  const MessagesPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillPrimaryContainer,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildAppBarSection(context),
                SizedBox(height: 8.v),
                _buildUserProfileSection(context)
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppBarSection(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 5.v),
      decoration: AppDecoration.fillBlue200,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 6.v),
          CustomAppBar(
            height: 19.v,
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgSearchBlack90001,
                margin: EdgeInsets.symmetric(horizontal: 16.h),
              )
            ],
          ),
          SizedBox(height: 19.v),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Text(
              "Messages",
              style: theme.textTheme.displaySmall,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 4.5.v),
            child: SizedBox(
              width: 298.h,
              child: Divider(
                height: 1.v,
                thickness: 1.v,
                color: appTheme.blueGray50,
              ),
            ),
          );
        },
        itemCount: 9,
        itemBuilder: (context, index) {
          return UserprofilesectionItemWidget();
        },
      ),
    );
  }
}
