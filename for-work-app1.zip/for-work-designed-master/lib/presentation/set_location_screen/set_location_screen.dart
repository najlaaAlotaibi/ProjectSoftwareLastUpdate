import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class SetLocationScreen extends StatelessWidget {
  const SetLocationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 32.h,
            top: 73.v,
            right: 32.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgLinkedin,
                height: 64.v,
                width: 52.h,
              ),
              SizedBox(height: 40.v),
              Container(
                width: 235.h,
                margin: EdgeInsets.only(right: 75.h),
                child: Text(
                  "Hello, nice to meet you!",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.displayMediumBlack90001,
                ),
              ),
              SizedBox(height: 10.v),
              Container(
                width: 284.h,
                margin: EdgeInsets.only(right: 26.h),
                child: Text(
                  "Set your location to start find a dream job around you",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.bodyLargeGray700_1.copyWith(
                    height: 1.29,
                  ),
                ),
              ),
              SizedBox(height: 40.v),
              CustomElevatedButton(
                text: "Use current location",
                leftIcon: Container(
                  margin: EdgeInsets.only(right: 30.h),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgUser,
                    height: 16.adaptSize,
                    width: 16.adaptSize,
                  ),
                ),
                buttonStyle: CustomButtonStyles.fillBlue,
                buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
                onPressed: () {
                  Navigator.pushNamed(
                      context, AppRoutes.personalInformationScreen);
                },
              ),
              SizedBox(height: 16.v),
              Container(
                width: 305.h,
                margin: EdgeInsets.only(right: 5.h),
                child: Text(
                  "We only access your location while you are using this incredible app",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.bodyMediumBluegray400_1.copyWith(
                    height: 1.38,
                  ),
                ),
              ),
              SizedBox(height: 42.v),
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, AppRoutes.chooseLocationScreen);
                },
                child: Text(
                  "or set your location manually",
                  style: theme.textTheme.bodyLarge,
                ),
              ),
              SizedBox(height: 5.v)
            ],
          ),
        ),
      ),
    );
  }
}
