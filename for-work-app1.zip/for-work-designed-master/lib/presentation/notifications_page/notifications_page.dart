import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'widgets/interviewremind_item_widget.dart'; // ignore_for_file: must_be_immutable

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray50,
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillGray50,
          child: Column(
            children: [
              _buildAppBar(context),
              SizedBox(height: 16.v),
              _buildInterviewRemind(context)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 9.v),
      decoration: AppDecoration.outlineBlueGray,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          CustomAppBar(
            height: 16.v,
            leadingWidth: 36.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgFilterBlack90001,
              margin: EdgeInsets.only(left: 16.h),
            ),
            actions: [
              AppbarTrailingImage(
                imagePath: ImageConstant.imgIconMore,
                margin: EdgeInsets.fromLTRB(16.h, 5.v, 16.h, 6.v),
              )
            ],
          ),
          SizedBox(height: 16.v),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Text(
              "Notifications",
              style: theme.textTheme.displaySmall,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildInterviewRemind(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 8.v,
          );
        },
        itemCount: 5,
        itemBuilder: (context, index) {
          return InterviewremindItemWidget();
        },
      ),
    );
  }
}
