import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class InterviewremindItemWidget extends StatelessWidget {
  const InterviewremindItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15.h),
      decoration: AppDecoration.outlineBluegray501.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Interview Reminder",
                style: theme.textTheme.titleSmall,
              ),
              SizedBox(height: 5.v),
              Text(
                "UX Designer",
                style: theme.textTheme.bodyMedium,
              ),
              SizedBox(height: 3.v),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "Creatio Studio in ",
                      style: theme.textTheme.bodyMedium,
                    ),
                    TextSpan(
                      text: "Al Farwaniyah, KW",
                      style: theme.textTheme.bodyMedium,
                    )
                  ],
                ),
                textAlign: TextAlign.left,
              )
            ],
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 43.v),
            child: Text(
              "1h",
              style: theme.textTheme.bodyMedium,
            ),
          )
        ],
      ),
    );
  }
}
