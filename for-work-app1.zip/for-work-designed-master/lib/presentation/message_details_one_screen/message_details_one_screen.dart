import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';

class MessageDetailsOneScreen extends StatelessWidget {
  const MessageDetailsOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Container(
            height: 768.v,
            width: double.maxFinite,
            decoration: AppDecoration.fillPrimaryContainer,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgRectangle1110,
                  height: 635.v,
                  width: 375.h,
                  alignment: Alignment.topCenter,
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(38.h, 13.v, 47.h, 40.v),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgRectangle1,
                          height: 150.v,
                          width: 120.h,
                          radius: BorderRadius.circular(
                            20.h,
                          ),
                          alignment: Alignment.centerLeft,
                        ),
                        Spacer(),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 5.h,
                            right: 17.h,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomIconButton(
                                height: 55.adaptSize,
                                width: 55.adaptSize,
                                padding: EdgeInsets.all(15.h),
                                decoration: IconButtonStyleHelper.fillRed,
                                child: CustomImageView(
                                  imagePath:
                                      ImageConstant.imgTelevisionGray30002,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 16.h),
                                child: CustomIconButton(
                                  height: 55.adaptSize,
                                  width: 55.adaptSize,
                                  padding: EdgeInsets.all(15.h),
                                  decoration: IconButtonStyleHelper.fillGray,
                                  child: CustomImageView(
                                    imagePath:
                                        ImageConstant.imgSettingsOnprimary,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 16.h),
                                child: CustomIconButton(
                                  height: 55.adaptSize,
                                  width: 55.adaptSize,
                                  padding: EdgeInsets.all(15.h),
                                  decoration: IconButtonStyleHelper.fillGray,
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgMusic,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 16.h),
                                child: CustomIconButton(
                                  height: 55.adaptSize,
                                  width: 55.adaptSize,
                                  padding: EdgeInsets.all(15.h),
                                  decoration: IconButtonStyleHelper.fillGray,
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgUploadBlack900,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: 38.v),
                        CustomElevatedButton(
                          height: 69.v,
                          text: "Sr. Product Manager",
                          leftIcon: Container(
                            padding:
                                EdgeInsets.fromLTRB(17.h, 15.v, 16.h, 15.v),
                            margin: EdgeInsets.only(right: 16.h),
                            decoration: BoxDecoration(
                              color: appTheme.gray5001,
                              borderRadius: BorderRadius.circular(
                                30.h,
                              ),
                            ),
                            child: CustomImageView(
                              imagePath: ImageConstant.imgApple131,
                              height: 30.v,
                              width: 26.h,
                            ),
                          ),
                          buttonStyle: CustomButtonStyles.fillBlueTL16,
                          buttonTextStyle:
                              CustomTextStyles.titleMediumPoppinsBlack900,
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
