import 'package:flutter/material.dart';
import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_button.dart'; // ignore: must_be_immutable

class ThumbnailItemWidget extends StatelessWidget {
  const ThumbnailItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 138.h,
      child: Align(
        alignment: Alignment.centerRight,
        child: SizedBox(
          height: 86.v,
          width: 138.h,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.center,
                child: Text(
                  "138 x 86",
                  style: CustomTextStyles.headlineSmallBluegray400,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: 86.v,
                  width: 138.h,
                  padding: EdgeInsets.symmetric(
                    horizontal: 53.h,
                    vertical: 27.v,
                  ),
                  decoration: AppDecoration.fillBlack.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder8,
                  ),
                  child: CustomIconButton(
                    height: 32.adaptSize,
                    width: 32.adaptSize,
                    padding: EdgeInsets.all(9.h),
                    decoration: IconButtonStyleHelper.outlinePrimaryContainer,
                    alignment: Alignment.center,
                    child: CustomImageView(
                      imagePath: ImageConstant.imgOverflowMenu,
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
