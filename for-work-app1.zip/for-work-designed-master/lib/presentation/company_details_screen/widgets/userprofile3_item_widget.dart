import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class Userprofile3ItemWidget extends StatelessWidget {
  const Userprofile3ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.h),
      decoration: AppDecoration.fillBlueGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 224.h,
            child: Row(
              children: [
                Container(
                  width: 45.adaptSize,
                  padding: EdgeInsets.symmetric(
                    horizontal: 9.h,
                    vertical: 16.v,
                  ),
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder22,
                  ),
                  child: Text(
                    "45 x 45",
                    style: theme.textTheme.labelSmall,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 14.v,
                    bottom: 14.v,
                  ),
                  child: Text(
                    "Brave Studio",
                    style: theme.textTheme.labelLarge,
                  ),
                ),
                Spacer(),
                CustomImageView(
                  imagePath: ImageConstant.imgBookmark,
                  height: 20.v,
                  width: 15.h,
                  margin: EdgeInsets.only(bottom: 25.v),
                )
              ],
            ),
          ),
          SizedBox(height: 10.v),
          Text(
            "Product Designer",
            style: CustomTextStyles.titleMediumMedium_1,
          ),
          SizedBox(height: 4.v),
          Text(
            "7363 California, USA",
            style: theme.textTheme.bodyMedium,
          ),
          SizedBox(height: 17.v),
          Row(
            children: [
              Text(
                "90K/hr",
                style: theme.textTheme.titleSmall,
              ),
              Container(
                width: 66.h,
                margin: EdgeInsets.only(left: 13.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 8.h,
                  vertical: 1.v,
                ),
                decoration: AppDecoration.fillGray.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder8,
                ),
                child: Text(
                  "Fulltime",
                  style: CustomTextStyles.labelLargeGray700,
                ),
              ),
              Container(
                width: 64.h,
                margin: EdgeInsets.only(left: 8.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 8.h,
                  vertical: 1.v,
                ),
                decoration: AppDecoration.fillGray.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder8,
                ),
                child: Text(
                  "Remote",
                  style: CustomTextStyles.labelLargeGray700,
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
