import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_rating_bar.dart';
import 'widgets/column_item_widget.dart';
import 'widgets/listprice_item_widget.dart';
import 'widgets/thumbnail_item_widget.dart';
import 'widgets/userprofile3_item_widget.dart';

class CompanyDetailsScreen extends StatelessWidget {
  const CompanyDetailsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppbar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(top: 1.v),
            child: Padding(
              padding: EdgeInsets.only(bottom: 5.v),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildStackvacantland(context),
                  SizedBox(height: 27.v),
                  Padding(
                    padding: EdgeInsets.only(left: 16.h),
                    child: Text(
                      "About",
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                  SizedBox(height: 12.v),
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      width: 337.h,
                      child: ReadMoreText(
                        "From the glamorous San Francisco social scene of the 1920s, through war and the social changes of the ’60s, to the rise of Silicon Valley today, this extraordinary novel takes us on a family odyssey that is both heartbr…. ",
                        trimLines: 5,
                        colorClickableText: appTheme.blue700,
                        trimMode: TrimMode.Line,
                        trimCollapsedText: "read more",
                        moreStyle:
                            CustomTextStyles.bodyMediumBlack9000115.copyWith(
                          height: 1.33,
                        ),
                        lessStyle:
                            CustomTextStyles.bodyMediumBlack9000115.copyWith(
                          height: 1.33,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 27.v),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.h),
                    child: _buildTitle(
                      context,
                      watchVideoText: "Photos",
                      seeAllText: "See all",
                    ),
                  ),
                  SizedBox(height: 12.v),
                  _buildColumn(context),
                  SizedBox(height: 27.v),
                  _buildOverview(context),
                  SizedBox(height: 29.v),
                  _buildHeadquarters(context),
                  SizedBox(height: 28.v),
                  _buildColumnwatchvide(context),
                  SizedBox(height: 27.v),
                  Padding(
                    padding: EdgeInsets.only(left: 16.h),
                    child: Text(
                      "Social Media",
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                  SizedBox(height: 12.v),
                  Padding(
                    padding: EdgeInsets.only(left: 16.h),
                    child: Row(
                      children: [
                        CustomIconButton(
                          height: 40.adaptSize,
                          width: 40.adaptSize,
                          padding: EdgeInsets.all(10.h),
                          decoration: IconButtonStyleHelper.fillBlueGray,
                          child: CustomImageView(
                            imagePath: ImageConstant.imgFacebook,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: CustomIconButton(
                            height: 40.adaptSize,
                            width: 40.adaptSize,
                            padding: EdgeInsets.all(10.h),
                            decoration: IconButtonStyleHelper.fillBlueGray,
                            child: CustomImageView(
                              imagePath: ImageConstant.imgInfo,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: CustomIconButton(
                            height: 40.adaptSize,
                            width: 40.adaptSize,
                            padding: EdgeInsets.all(10.h),
                            decoration: IconButtonStyleHelper.fillBlueGray,
                            child: CustomImageView(
                              imagePath: ImageConstant.imgIconYoutube,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 16.h),
                          child: CustomIconButton(
                            height: 40.adaptSize,
                            width: 40.adaptSize,
                            padding: EdgeInsets.all(10.h),
                            decoration: IconButtonStyleHelper.fillBlueGray,
                            child: CustomImageView(
                              imagePath: ImageConstant.imgTrash,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 27.v),
                  _buildColumnavailable(context),
                  SizedBox(height: 43.v),
                  Padding(
                    padding: EdgeInsets.only(left: 21.h),
                    child: Text(
                      "Reviews",
                      style: theme.textTheme.titleMedium,
                    ),
                  ),
                  SizedBox(height: 20.v),
                  _buildRowoutoffive(context),
                  SizedBox(height: 16.v),
                  Padding(
                    padding: EdgeInsets.only(left: 21.h),
                    child: Text(
                      "Reviews",
                      style: CustomTextStyles.bodyMediumBluegray400,
                    ),
                  ),
                  SizedBox(height: 17.v),
                  Padding(
                    padding: EdgeInsets.only(left: 21.h),
                    child: Row(
                      children: [
                        Container(
                          width: 40.adaptSize,
                          padding: EdgeInsets.symmetric(
                            horizontal: 7.h,
                            vertical: 13.v,
                          ),
                          decoration: AppDecoration.fillGray.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder22,
                          ),
                          child: Text(
                            "40 x 40",
                            style: theme.textTheme.labelSmall,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 7.h,
                            top: 2.v,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Sri Wedari Soekarno",
                                style: CustomTextStyles.bodyMediumBlack9000115,
                              ),
                              SizedBox(height: 2.v),
                              SizedBox(
                                width: 145.h,
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                        top: 1.v,
                                        bottom: 3.v,
                                      ),
                                      child: CustomRatingBar(
                                        initialRating: 0,
                                        itemSize: 10,
                                      ),
                                    ),
                                    Text(
                                      "15 minutes ago",
                                      style: CustomTextStyles.bodySmall12,
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 8.v),
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      width: 328.h,
                      margin: EdgeInsets.only(
                        left: 21.h,
                        right: 25.h,
                      ),
                      child: Text(
                        "They has been responsible for developing our annual marketing/advertising plans, creating all ads and graphics, promotional materials and web site design, consistent creative quality!",
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        style: CustomTextStyles.bodyMediumBlack9000115.copyWith(
                          height: 1.33,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 16.v),
                  Align(
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgPlus,
                          height: 13.adaptSize,
                          width: 13.adaptSize,
                          margin: EdgeInsets.only(
                            top: 2.v,
                            bottom: 1.v,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 8.h),
                          child: Text(
                            "7 More Reviews",
                            style: CustomTextStyles.titleSmallBluegray400,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 43.v,
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowPrimarycontainer,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 11.v,
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgIconMorePrimarycontainer,
          margin: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 19.v,
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildStackvacantland(BuildContext context) {
    return SizedBox(
      height: 188.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 16.h,
                vertical: 24.v,
              ),
              decoration: AppDecoration.gradientBlackToBlack,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 14.v),
                  Text(
                    "Baims",
                    style: CustomTextStyles.headlineMediumPrimaryContainer,
                  ),
                  SizedBox(height: 8.v),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgLinkedinPrimarycontainer,
                        height: 12.v,
                        width: 10.h,
                        margin: EdgeInsets.only(
                          top: 2.v,
                          bottom: 3.v,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 8.h),
                        child: Text(
                          "San Francisco, CA",
                          style: CustomTextStyles.bodyMediumPrimaryContainer15,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 10.v),
                  Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                          top: 1.v,
                          bottom: 2.v,
                        ),
                        child: CustomRatingBar(
                          initialRating: 0,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 7.h),
                        child: Text(
                          "4.9 (349 ratings)",
                          style: CustomTextStyles.bodyMediumPrimaryContainer15,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  margin: EdgeInsets.only(bottom: 12.v),
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.h,
                    vertical: 23.v,
                  ),
                  decoration: AppDecoration.fillBlueGray.copyWith(
                    borderRadius: BorderRadiusStyle.circleBorder32,
                  ),
                  child: Text(
                    "64 x 64",
                    style: CustomTextStyles.titleSmallBluegray400,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 15.h,
                    top: 19.v,
                  ),
                  child: Text(
                    "375 x 276",
                    style: theme.textTheme.displayMedium,
                  ),
                ),
                CustomElevatedButton(
                  height: 29.v,
                  width: 74.h,
                  text: "Follow",
                  margin: EdgeInsets.only(
                    left: 6.h,
                    top: 18.v,
                    bottom: 29.v,
                  ),
                  buttonStyle: CustomButtonStyles.fillBlueTL4,
                  buttonTextStyle: CustomTextStyles.bodyMediumPrimaryContainer,
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumn(BuildContext context) {
    return SizedBox(
      height: 122.v,
      child: ListView.separated(
        padding: EdgeInsets.only(left: 16.h),
        scrollDirection: Axis.horizontal,
        separatorBuilder: (context, index) {
          return SizedBox(
            width: 16.h,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return ColumnItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildOverview(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(left: 16.h),
          child: Text(
            "Overview",
            style: theme.textTheme.titleMedium,
          ),
        ),
        SizedBox(height: 12.v),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            right: 47.h,
          ),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Industry",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 13.v,
                  bottom: 10.v,
                ),
                child: Text(
                  "Design & Creative",
                  style: theme.textTheme.bodyLarge,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.h),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Company Size",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 11.v,
                  bottom: 12.v,
                ),
                child: Text(
                  "100-500",
                  style: theme.textTheme.bodyLarge,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            right: 75.h,
          ),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 11.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Phone",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 11.v,
                  bottom: 12.v,
                ),
                child: Text(
                  "123 456 7890",
                  style: theme.textTheme.bodyLarge,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            right: 57.h,
          ),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 11.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Email",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 13.v,
                  bottom: 10.v,
                ),
                child: Text(
                  "hello@mail.com",
                  style: theme.textTheme.bodyLarge,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            right: 43.h,
          ),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 11.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Location",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 13.v,
                  bottom: 10.v,
                ),
                child: Text(
                  "San Francisco, CA",
                  style: theme.textTheme.bodyLarge,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            right: 59.h,
          ),
          child: Row(
            children: [
              Container(
                width: 163.h,
                padding: EdgeInsets.symmetric(
                  horizontal: 16.h,
                  vertical: 11.v,
                ),
                decoration: AppDecoration.fillGray50,
                child: Text(
                  "Website",
                  style: CustomTextStyles.bodyLargeGray700_1,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 11.v,
                  bottom: 12.v,
                ),
                child: Text(
                  "vacantland.com",
                  style: CustomTextStyles.bodyLargeBlue700,
                ),
              )
            ],
          ),
        ),
        Divider(
          indent: 16.h,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildHeadquarters(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Headquarters",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 18.v),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 255.h,
                      child: Text(
                        "43 Bourke Street, Newbridge NSW 837\nRaffles Place, Boat Band M83",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: CustomTextStyles.bodyMediumBlack9000115.copyWith(
                          height: 1.33,
                        ),
                      ),
                    ),
                    SizedBox(height: 3.v),
                    Text(
                      "1.3 km",
                      style: CustomTextStyles.bodySmall12,
                    )
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 55.h,
                  top: 3.v,
                  bottom: 23.v,
                ),
                child: CustomIconButton(
                  height: 32.adaptSize,
                  width: 32.adaptSize,
                  padding: EdgeInsets.all(8.h),
                  decoration: IconButtonStyleHelper.fillBlue,
                  child: CustomImageView(
                    imagePath: ImageConstant.imgUser,
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnwatchvide(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: _buildTitle(
            context,
            watchVideoText: "Watch Video",
            seeAllText: "See all",
          ),
        ),
        SizedBox(height: 12.v),
        Align(
          alignment: Alignment.centerRight,
          child: SizedBox(
            height: 86.v,
            child: ListView.separated(
              padding: EdgeInsets.only(left: 20.h),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(
                  width: 16.h,
                );
              },
              itemCount: 3,
              itemBuilder: (context, index) {
                return ThumbnailItemWidget();
              },
            ),
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildColumnavailable(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: _buildTitle(
            context,
            watchVideoText: "Available Jobs",
            seeAllText: "See all",
          ),
        ),
        SizedBox(height: 12.v),
        Padding(
          padding: EdgeInsets.only(left: 16.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: ListView.separated(
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) {
                    return SizedBox(
                      height: 1.v,
                    );
                  },
                  itemCount: 1,
                  itemBuilder: (context, index) {
                    return Userprofile3ItemWidget();
                  },
                ),
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 16.h),
                  padding: EdgeInsets.all(16.h),
                  decoration: AppDecoration.fillBlueGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder8,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: 1.v),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 149.h,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    width: 45.adaptSize,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 9.h,
                                      vertical: 16.v,
                                    ),
                                    decoration: AppDecoration.fillGray.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder22,
                                    ),
                                    child: Text(
                                      "45 x 45",
                                      style: theme.textTheme.labelSmall,
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 14.v),
                                    child: Text(
                                      "Limited Sounds",
                                      style: theme.textTheme.labelLarge,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(height: 10.v),
                            Text(
                              "Finance Manager",
                              style: CustomTextStyles.titleMediumMedium_1,
                            ),
                            SizedBox(height: 4.v),
                            Text(
                              "Los Angeles, CA",
                              style: theme.textTheme.bodyMedium,
                            ),
                            SizedBox(height: 17.v),
                            SizedBox(
                              height: 18.v,
                              child: ListView.separated(
                                padding: EdgeInsets.only(right: 15.h),
                                scrollDirection: Axis.horizontal,
                                separatorBuilder: (context, index) {
                                  return SizedBox(
                                    width: 13.h,
                                  );
                                },
                                itemCount: 2,
                                itemBuilder: (context, index) {
                                  return ListpriceItemWidget();
                                },
                              ),
                            )
                          ],
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgBookmark,
                        height: 20.v,
                        width: 15.h,
                        margin: EdgeInsets.only(bottom: 113.v),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildRowoutoffive(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.only(
          left: 21.h,
          right: 11.h,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 14.h,
                vertical: 9.v,
              ),
              decoration: AppDecoration.outlineBluegray501.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder8,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "4.6",
                    style: theme.textTheme.displaySmall,
                  ),
                  SizedBox(height: 1.v),
                  Text(
                    "out of 5",
                    style: theme.textTheme.bodyMedium,
                  )
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgStars,
                      height: 10.v,
                      width: 54.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 7.h,
                        top: 3.v,
                        bottom: 3.v,
                      ),
                      child: Container(
                        height: 4.v,
                        width: 177.h,
                        decoration: BoxDecoration(
                          color: appTheme.blueGray50,
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                          child: LinearProgressIndicator(
                            value: 0.82,
                            backgroundColor: appTheme.blueGray50,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              appTheme.blue700,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 8.v),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgStarsGray400,
                      height: 10.v,
                      width: 43.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 7.h,
                        top: 3.v,
                        bottom: 3.v,
                      ),
                      child: Container(
                        height: 4.v,
                        width: 177.h,
                        decoration: BoxDecoration(
                          color: appTheme.blueGray50,
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                          child: LinearProgressIndicator(
                            value: 0.58,
                            backgroundColor: appTheme.blueGray50,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              appTheme.blue700,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 7.v),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgStarsGray40010x32,
                      height: 10.v,
                      width: 32.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 7.h,
                        top: 3.v,
                        bottom: 3.v,
                      ),
                      child: Container(
                        height: 4.v,
                        width: 177.h,
                        decoration: BoxDecoration(
                          color: appTheme.blueGray50,
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                          child: LinearProgressIndicator(
                            value: 0.38,
                            backgroundColor: appTheme.blueGray50,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              appTheme.blue700,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 8.v),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgStarsGray40010x21,
                      height: 10.v,
                      width: 21.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 7.h,
                        top: 3.v,
                        bottom: 3.v,
                      ),
                      child: Container(
                        height: 4.v,
                        width: 177.h,
                        decoration: BoxDecoration(
                          color: appTheme.blueGray50,
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                          child: LinearProgressIndicator(
                            value: 0.71,
                            backgroundColor: appTheme.blueGray50,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              appTheme.blue700,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 7.v),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgStarsGray40010x10,
                      height: 10.adaptSize,
                      width: 10.adaptSize,
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        left: 7.h,
                        top: 3.v,
                        bottom: 3.v,
                      ),
                      child: Container(
                        height: 4.v,
                        width: 177.h,
                        decoration: BoxDecoration(
                          color: appTheme.blueGray50,
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            2.h,
                          ),
                          child: LinearProgressIndicator(
                            value: 0.18,
                            backgroundColor: appTheme.blueGray50,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              appTheme.blue700,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                )
              ],
            )
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildTitle(
    BuildContext context, {
    required String watchVideoText,
    required String seeAllText,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          watchVideoText,
          style: theme.textTheme.titleMedium!.copyWith(
            color: appTheme.black90001,
          ),
        ),
        Spacer(),
        Padding(
          padding: EdgeInsets.only(
            top: 4.v,
            bottom: 3.v,
          ),
          child: Text(
            seeAllText,
            style: theme.textTheme.labelMedium!.copyWith(
              color: appTheme.blueGray400,
            ),
          ),
        ),
        CustomImageView(
          imagePath: ImageConstant.imgArrowRightBlueGray400,
          height: 8.v,
          width: 4.h,
          margin: EdgeInsets.only(
            left: 2.h,
            top: 7.v,
            bottom: 4.v,
          ),
        )
      ],
    );
  }
}
