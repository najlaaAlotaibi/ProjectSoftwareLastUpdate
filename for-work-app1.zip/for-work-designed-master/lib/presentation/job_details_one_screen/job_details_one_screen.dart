import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_rating_bar.dart';
import 'widgets/userprofile2_item_widget.dart';

class JobDetailsOneScreen extends StatelessWidget {
  const JobDetailsOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 1.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 23.v),
                              child: CustomIconButton(
                                height: 40.adaptSize,
                                width: 40.adaptSize,
                                padding: EdgeInsets.all(9.h),
                                decoration:
                                    IconButtonStyleHelper.outlineBlueGray,
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgTwitter,
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 24.h),
                              padding: EdgeInsets.symmetric(
                                horizontal: 18.h,
                                vertical: 32.v,
                              ),
                              decoration: AppDecoration.fillGray.copyWith(
                                borderRadius: BorderRadiusStyle.circleBorder43,
                              ),
                              child: Text(
                                "86 x 86",
                                style: CustomTextStyles
                                    .titleMediumBluegray400SemiBold,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                left: 24.h,
                                top: 23.v,
                                bottom: 23.v,
                              ),
                              child: CustomIconButton(
                                height: 40.adaptSize,
                                width: 40.adaptSize,
                                padding: EdgeInsets.all(10.h),
                                decoration:
                                    IconButtonStyleHelper.outlineBlueGray,
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgBookmarkRedA400,
                                ),
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 16.v),
                        Text(
                          "Senior Software Engineer",
                          style: CustomTextStyles.headlineSmallBlack90001,
                        ),
                        SizedBox(height: 6.v),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(bottom: 1.v),
                              child: Text(
                                "Creatio Studio",
                                style: CustomTextStyles.bodyMediumBlack9000115,
                              ),
                            ),
                            Container(
                              height: 3.adaptSize,
                              width: 3.adaptSize,
                              margin: EdgeInsets.only(
                                left: 8.h,
                                top: 8.v,
                                bottom: 7.v,
                              ),
                              decoration: BoxDecoration(
                                color: appTheme.blueGray400,
                                borderRadius: BorderRadius.circular(
                                  1.h,
                                ),
                              ),
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgLinkedinBlueGray400,
                              height: 12.v,
                              width: 10.h,
                              margin: EdgeInsets.only(
                                left: 8.h,
                                top: 3.v,
                                bottom: 3.v,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 8.h),
                              child: Text(
                                "San Francisco, CA",
                                style: CustomTextStyles.bodyMedium15,
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 10.v),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(
                                top: 1.v,
                                bottom: 2.v,
                              ),
                              child: CustomRatingBar(
                                initialRating: 0,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 7.h),
                              child: Text(
                                "4.9 (349 ratings)",
                                style: CustomTextStyles.bodyMedium15,
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 52.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "Job Overview",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 12.v),
                        _buildStackDivider(context),
                        SizedBox(height: 29.v),
                        _buildApplicant(context),
                        SizedBox(height: 29.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "Description",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 18.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "About",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 9.v),
                        Container(
                          width: 339.h,
                          margin: EdgeInsets.only(
                            left: 16.h,
                            right: 19.h,
                          ),
                          child: Text(
                            "We creates software that empowers everyone from small start-ups to large enterprises and helps teams everywhere change the world. Our products are revolutionizing the software industry and helping teams collaborate.",
                            maxLines: 5,
                            overflow: TextOverflow.ellipsis,
                            style: CustomTextStyles.bodyMediumBlack9000115
                                .copyWith(
                              height: 1.33,
                            ),
                          ),
                        ),
                        SizedBox(height: 16.v),
                        _buildStackDescription(context),
                        SizedBox(height: 27.v),
                        _buildLocation(context),
                        SizedBox(height: 27.v),
                        _buildColumnRelatedJobs(context)
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        bottomNavigationBar: _buildApplyNow(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 43.v,
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrow,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 11.v,
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgIconMore,
          margin: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 19.v,
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildStackDivider(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 0,
      margin: EdgeInsets.all(0),
      color: theme.colorScheme.primaryContainer.withOpacity(1),
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: appTheme.blueGray100,
          width: 1.h,
        ),
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Container(
        height: 291.v,
        width: 343.h,
        decoration: AppDecoration.outlineBluegray100.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder8,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(bottom: 72.v),
                child: SizedBox(
                  width: 343.h,
                  child: Divider(),
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: SizedBox(
                width: 343.h,
                child: Divider(),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: EdgeInsets.only(top: 72.v),
                child: SizedBox(
                  width: 343.h,
                  child: Divider(),
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: SizedBox(
                height: 291.v,
                child: VerticalDivider(
                  width: 1.h,
                  thickness: 1.v,
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: EdgeInsets.only(
                  right: 49.h,
                  bottom: 17.v,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 24.adaptSize,
                      width: 24.adaptSize,
                      margin: EdgeInsets.symmetric(vertical: 6.v),
                      padding: EdgeInsets.symmetric(
                        horizontal: 1.h,
                        vertical: 4.v,
                      ),
                      decoration: AppDecoration.fillPrimaryContainer,
                      child: CustomImageView(
                        imagePath: ImageConstant.imgContrastBlue700,
                        height: 15.v,
                        width: 22.h,
                        alignment: Alignment.bottomCenter,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Salary",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 3.v),
                          Text(
                            "2K - 7K",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: EdgeInsets.only(
                  top: 89.v,
                  right: 56.h,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: 7.v,
                        bottom: 8.v,
                      ),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgBagBlue700,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Job Title",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 5.v),
                          Text(
                            "Engineer",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: EdgeInsets.only(
                  right: 51.h,
                  bottom: 89.v,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: 6.v,
                        bottom: 8.v,
                      ),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgTicket,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Experience",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 4.v),
                          Text(
                            "2+ years",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 89.v,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 7.v),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgLinkedin,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Location",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 5.v),
                          Text(
                            "Irvine, CA",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  bottom: 90.v,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: 7.v,
                        bottom: 6.v,
                      ),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgClock,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Hours",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 4.v),
                          Text(
                            "50h / week",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  bottom: 17.v,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: 7.v,
                        bottom: 6.v,
                      ),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgThumbsUp,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Rate",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 4.v),
                          Text(
                            "500 / hour",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 16.h,
                  top: 16.v,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 7.v),
                      child: CustomIconButton(
                        height: 24.adaptSize,
                        width: 24.adaptSize,
                        padding: EdgeInsets.all(2.h),
                        child: CustomImageView(
                          imagePath: ImageConstant.imgCalendarBlue700,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Date Posted",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 5.v),
                          Text(
                            "2 hours ago",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: EdgeInsets.only(
                  top: 17.v,
                  right: 27.h,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 24.adaptSize,
                      width: 24.adaptSize,
                      margin: EdgeInsets.symmetric(vertical: 7.v),
                      padding: EdgeInsets.symmetric(
                        horizontal: 4.h,
                        vertical: 1.v,
                      ),
                      decoration: AppDecoration.fillPrimaryContainer,
                      child: CustomImageView(
                        imagePath: ImageConstant.imgIconTime,
                        height: 22.v,
                        width: 16.h,
                        alignment: Alignment.center,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 16.h),
                      child: Column(
                        children: [
                          Text(
                            "Expiration Date",
                            style: theme.textTheme.bodyMedium,
                          ),
                          SizedBox(height: 4.v),
                          Text(
                            "Jan 12, 2027",
                            style: theme.textTheme.titleSmall,
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildApplicant(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTitle(
            context,
            relatedJobsText: "Applicant",
            seeAllText: "See all",
          ),
          SizedBox(height: 18.v),
          Row(
            children: [
              SizedBox(
                height: 40.v,
                width: 90.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.centerRight,
                      child: Container(
                        margin: EdgeInsets.only(left: 49.h),
                        padding: EdgeInsets.symmetric(
                          horizontal: 6.h,
                          vertical: 12.v,
                        ),
                        decoration:
                            AppDecoration.outlinePrimaryContainer.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder22,
                        ),
                        child: Text(
                          "40 x 40",
                          style: theme.textTheme.labelSmall,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 24.h),
                        padding: EdgeInsets.symmetric(
                          horizontal: 6.h,
                          vertical: 12.v,
                        ),
                        decoration:
                            AppDecoration.outlinePrimaryContainer.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder22,
                        ),
                        child: Text(
                          "40 x 40",
                          style: theme.textTheme.labelSmall,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        width: 40.adaptSize,
                        padding: EdgeInsets.symmetric(
                          horizontal: 7.h,
                          vertical: 13.v,
                        ),
                        decoration:
                            AppDecoration.outlinePrimaryContainer.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder22,
                        ),
                        child: Text(
                          "40 x 40",
                          style: theme.textTheme.labelSmall,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Container(
                width: 40.adaptSize,
                margin: EdgeInsets.only(left: 16.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 11.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.fillBlueGray.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder22,
                ),
                child: Text(
                  "+5",
                  style: CustomTextStyles.bodyMediumBluegray400,
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildStackDescription(BuildContext context) {
    return SizedBox(
      height: 86.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          Align(
            alignment: Alignment.bottomLeft,
            child: Container(
              width: 317.h,
              margin: EdgeInsets.only(left: 16.h),
              child: Text(
                "To support you at work, our perks and benefits include ample time off, an annual education budget, paid volunteer days, and so much more.",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: CustomTextStyles.bodyMediumBlack9000115.copyWith(
                  height: 1.33,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Text(
                "Benefits",
                style: theme.textTheme.bodyMedium,
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(
                horizontal: 161.h,
                vertical: 8.v,
              ),
              decoration:
                  AppDecoration.gradientPrimaryContainerToPrimaryContainer,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgArrowDownBlue700,
                    height: 6.v,
                    width: 10.h,
                    margin: EdgeInsets.only(
                      top: 58.v,
                      bottom: 4.v,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      top: 52.v,
                      right: 7.h,
                    ),
                    child: Text(
                      "More",
                      style: CustomTextStyles.titleSmallSemiBold,
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildLocation(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Location",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 20.v),
          Container(
            width: 255.h,
            margin: EdgeInsets.only(right: 87.h),
            child: Text(
              "43 Bourke Street, Newbridge NSW 837\nRaffles Place, Boat Band M83",
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: CustomTextStyles.bodyMediumBlack9000115.copyWith(
                height: 1.33,
              ),
            ),
          ),
          SizedBox(height: 15.v),
          SizedBox(
            height: 224.v,
            width: 343.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "343 x 224",
                    style: theme.textTheme.displayMedium,
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 16.h,
                      vertical: 8.v,
                    ),
                    decoration: AppDecoration
                        .gradientPrimaryContainerToPrimaryContainer1
                        .copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder8,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Distance",
                                  style: theme.textTheme.bodyMedium,
                                ),
                                SizedBox(height: 1.v),
                                Align(
                                  alignment: Alignment.center,
                                  child: RichText(
                                    text: TextSpan(
                                      children: [
                                        TextSpan(
                                          text: "10.23 ",
                                          style: theme.textTheme.labelLarge,
                                        ),
                                        TextSpan(
                                          text: "km",
                                          style: theme.textTheme.bodyMedium,
                                        )
                                      ],
                                    ),
                                    textAlign: TextAlign.left,
                                  ),
                                )
                              ],
                            ),
                            Spacer(
                              flex: 18,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Time",
                                  style: theme.textTheme.bodyMedium,
                                ),
                                SizedBox(height: 1.v),
                                RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "24 ",
                                        style: theme.textTheme.labelLarge,
                                      ),
                                      TextSpan(
                                        text: "min",
                                        style: theme.textTheme.bodyMedium,
                                      )
                                    ],
                                  ),
                                  textAlign: TextAlign.left,
                                )
                              ],
                            ),
                            Spacer(
                              flex: 81,
                            ),
                            CustomIconButton(
                              height: 35.adaptSize,
                              width: 35.adaptSize,
                              padding: EdgeInsets.all(10.h),
                              decoration: IconButtonStyleHelper.outlineBlue,
                              child: CustomImageView(
                                imagePath:
                                    ImageConstant.imgContrastBlue70035x35,
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 22.v),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 108.h),
                          padding: EdgeInsets.all(36.h),
                          decoration: AppDecoration.fillBlue7001.copyWith(
                            borderRadius: BorderRadiusStyle.circleBorder47,
                          ),
                          child: Container(
                            height: 22.adaptSize,
                            width: 22.adaptSize,
                            decoration: BoxDecoration(
                              color: appTheme.redA400,
                              borderRadius: BorderRadius.circular(
                                11.h,
                              ),
                              border: Border.all(
                                color: theme.colorScheme.primaryContainer
                                    .withOpacity(1),
                                width: 3.h,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: appTheme.black90001.withOpacity(0.2),
                                  spreadRadius: 2.h,
                                  blurRadius: 2.h,
                                  offset: Offset(
                                    0,
                                    0,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 57.v)
                      ],
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnRelatedJobs(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: _buildTitle(
            context,
            relatedJobsText: "Related Jobs",
            seeAllText: "See all",
          ),
        ),
        SizedBox(height: 12.v),
        SizedBox(
          height: 159.v,
          child: ListView.separated(
            padding: EdgeInsets.only(left: 16.h),
            scrollDirection: Axis.horizontal,
            separatorBuilder: (context, index) {
              return SizedBox(
                width: 16.h,
              );
            },
            itemCount: 3,
            itemBuilder: (context, index) {
              return Userprofile2ItemWidget();
            },
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildApplyNow(BuildContext context) {
    return CustomElevatedButton(
      text: "Apply Now",
      margin: EdgeInsets.only(
        left: 16.h,
        right: 16.h,
        bottom: 50.v,
      ),
      buttonStyle: CustomButtonStyles.fillBlue,
      buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
      onPressed: () {
        onTapApplyNow(context);
      },
    );
  }

  /// Common widget
  Widget _buildTitle(
    BuildContext context, {
    required String relatedJobsText,
    required String seeAllText,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          relatedJobsText,
          style: theme.textTheme.titleMedium!.copyWith(
            color: appTheme.black90001,
          ),
        ),
        Spacer(),
        Padding(
          padding: EdgeInsets.only(
            top: 4.v,
            bottom: 3.v,
          ),
          child: Text(
            seeAllText,
            style: theme.textTheme.labelMedium!.copyWith(
              color: appTheme.blueGray400,
            ),
          ),
        ),
        CustomImageView(
          imagePath: ImageConstant.imgArrowRightBlueGray400,
          height: 8.v,
          width: 4.h,
          margin: EdgeInsets.only(
            left: 2.h,
            top: 7.v,
            bottom: 4.v,
          ),
        )
      ],
    );
  }

  /// Navigates to the applyJobScreen when the action is triggered.
  onTapApplyNow(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.applyJobScreen);
  }
}
