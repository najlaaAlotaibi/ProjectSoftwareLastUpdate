import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class Userprofile2ItemWidget extends StatelessWidget {
  const Userprofile2ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15.h),
      decoration: AppDecoration.outlineBluegray100.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      width: 155.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 45.adaptSize,
                padding: EdgeInsets.symmetric(
                  horizontal: 9.h,
                  vertical: 16.v,
                ),
                decoration: AppDecoration.fillGray.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder22,
                ),
                child: Text(
                  "45 x 45",
                  style: theme.textTheme.labelSmall,
                ),
              ),
              SizedBox(height: 8.v),
              Text(
                "Brave Studio",
                style: CustomTextStyles.bodyMediumBlack90001,
              ),
              SizedBox(height: 18.v),
              Text(
                "3D Animator",
                style: theme.textTheme.titleSmall,
              ),
              SizedBox(height: 5.v),
              Text(
                "San Diego, CA",
                style: theme.textTheme.bodyMedium,
              )
            ],
          ),
          CustomImageView(
            imagePath: ImageConstant.imgBookmarkPrimarycontainer,
            height: 20.v,
            width: 15.h,
            margin: EdgeInsets.only(
              left: 24.h,
              bottom: 107.v,
            ),
          )
        ],
      ),
    );
  }
}
