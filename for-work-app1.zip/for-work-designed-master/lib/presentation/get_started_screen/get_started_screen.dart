import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class GetStartedScreen extends StatelessWidget {
  const GetStartedScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.blue200,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 1.v),
          child: Column(
            children: [
              SizedBox(
                height: 658.v,
                width: double.maxFinite,
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: SizedBox(
                        width: 284.h,
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "Find the job of \nyour ",
                                style: theme.textTheme.headlineLarge!.copyWith(
                                  height: 1.50,
                                ),
                              ),
                              TextSpan(
                                text: "dreams ",
                                style: CustomTextStyles.headlineLargeBlack90001,
                              ),
                              TextSpan(
                                text: "here",
                                style: theme.textTheme.headlineLarge,
                              )
                            ],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 1.h),
                        decoration: AppDecoration.outlineBlack,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(height: 76.v),
                            Container(
                              width: 349.h,
                              margin: EdgeInsets.only(
                                left: 19.h,
                                right: 5.h,
                              ),
                              decoration: AppDecoration.outlineBlack,
                              child: RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "Welcome to \n",
                                      style: CustomTextStyles
                                          .displayMediumMontserratPrimaryContainer40,
                                    ),
                                    TextSpan(
                                      text: "For Work",
                                      style: CustomTextStyles
                                          .displayMediumMontserratPrimaryContainer40,
                                    ),
                                    TextSpan(
                                      text: "🖐",
                                      style: CustomTextStyles
                                          .displayMediumMontserratPrimaryContainer40_1,
                                    )
                                  ],
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            SizedBox(height: 17.v),
                            CustomImageView(
                              imagePath:
                                  ImageConstant.imgJobHuntingRemovebgPreview,
                              height: 239.v,
                              width: 324.h,
                            ),
                            SizedBox(height: 17.v)
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 33.v),
              CustomElevatedButton(
                height: 54.v,
                text: "get started",
                margin: EdgeInsets.only(
                  left: 40.h,
                  right: 50.h,
                ),
                buttonStyle: CustomButtonStyles.fillPrimary,
                buttonTextStyle: CustomTextStyles.headlineLargePonnala,
                onPressed: () {
                  Navigator.of(context).pushNamed(AppRoutes.selectionsScreen);
                },
              ),
              SizedBox(height: 5.v)
            ],
          ),
        ),
      ),
    );
  }
}
