import 'package:another_stepper/dto/stepper_data.dart';
import 'package:another_stepper/widgets/another_stepper.dart';
import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class PersonalInformationScreen extends StatelessWidget {
  PersonalInformationScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController nameController = TextEditingController();

  TextEditingController phoneController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  List<String> dropdownItemList = ["Male", "Female"];

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 32.h,
                  vertical: 16.v,
                ),
                child: Column(
                  children: [
                    AnotherStepper(
                      stepperDirection: Axis.horizontal,
                      activeIndex: 0,
                      barThickness: 1,
                      inverted: true,
                      stepperList: [
                        StepperData(),
                        StepperData(),
                        StepperData(),
                        StepperData(),
                        StepperData()
                      ],
                    ),
                    SizedBox(height: 25.v),
                    _buildPersonalInformation(context),
                    SizedBox(height: 16.v),
                    _buildPhoneNumber(context),
                    SizedBox(height: 16.v),
                    _buildEmailAddress(context),
                    SizedBox(height: 16.v),
                    _buildGenderSelection(context),
                    SizedBox(height: 16.v),
                    _buildDateOfBirth(context),
                    SizedBox(height: 5.v)
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildContinueButton(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 12.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarSubtitleTwo(
        text: "Personal Information",
      ),
      actions: [
        AppbarSubtitleOne(
          text: "Save",
          margin: EdgeInsets.fromLTRB(16.h, 10.v, 16.h, 13.v),
        )
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildPersonalInformation(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Name",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 8.v),
        CustomTextFormField(
          controller: nameController,
          hintText: "Sara",
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildPhoneNumber(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Phone",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        CustomTextFormField(
          controller: phoneController,
          hintText: "Phone number",
          hintStyle: CustomTextStyles.bodyLargeBluegray400,
          textInputType: TextInputType.phone,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildEmailAddress(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Email",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        CustomTextFormField(
          controller: emailController,
          hintText: "SaraAhmed@gmail.com",
          textInputAction: TextInputAction.done,
          textInputType: TextInputType.emailAddress,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildGenderSelection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Gender",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        CustomDropDown(
          icon: Container(
            margin: EdgeInsets.symmetric(horizontal: 16.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgArrowdown,
              height: 6.v,
              width: 10.h,
            ),
          ),
          hintText: "Female",
          items: dropdownItemList,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildDateOfBirth(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Date of Birth",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        Container(
          padding: EdgeInsets.symmetric(
            horizontal: 16.h,
            vertical: 11.v,
          ),
          decoration: AppDecoration.fillBlueGray.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder8,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "DD/MM/YYYY",
                style: CustomTextStyles.bodyLargeBluegray400,
              ),
              CustomImageView(
                imagePath: ImageConstant.imgCalendar,
                height: 16.v,
                width: 14.h,
                margin: EdgeInsets.symmetric(vertical: 2.v),
              )
            ],
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildContinueButton(BuildContext context) {
    return CustomElevatedButton(
      text: "Continue",
      margin: EdgeInsets.only(
        left: 32.h,
        right: 32.h,
        bottom: 50.v,
      ),
      buttonTextStyle: theme.textTheme.headlineSmall!,
      onPressed: () {
        Navigator.pushNamed(context, AppRoutes.locationScreen);
      },
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
