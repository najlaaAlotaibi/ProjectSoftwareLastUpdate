import 'package:another_stepper/dto/stepper_data.dart';
import 'package:another_stepper/widgets/another_stepper.dart';
import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ExperienceScreen extends StatelessWidget {
  ExperienceScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController group106Controller = TextEditingController();

  TextEditingController nameController = TextEditingController();

  TextEditingController locationController = TextEditingController();

  bool background = false;

  TextEditingController dateController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 32.h,
                  vertical: 16.v,
                ),
                child: Column(
                  children: [
                    AnotherStepper(
                      stepperDirection: Axis.horizontal,
                      activeIndex: 3,
                      barThickness: 1,
                      inverted: true,
                      stepperList: [
                        StepperData(),
                        StepperData(),
                        StepperData(),
                        StepperData(),
                        StepperData()
                      ],
                    ),
                    SizedBox(height: 24.v),
                    _buildList01(context),
                    SizedBox(height: 18.v),
                    _buildList02(context),
                    SizedBox(height: 16.v),
                    _buildList03(context),
                    SizedBox(height: 16.v),
                    _buildBackground(context),
                    SizedBox(height: 16.v),
                    _buildRowStartDate(context),
                    SizedBox(height: 16.v),
                    _buildStackBackground(context),
                    SizedBox(height: 5.v)
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildNext(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 12.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarSubtitleTwo(
        text: "Experience",
      ),
      actions: [
        AppbarSubtitleOne(
          text: "Save",
          margin: EdgeInsets.fromLTRB(16.h, 10.v, 16.h, 13.v),
        )
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildList01(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Job Title",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        CustomTextFormField(
          controller: group106Controller,
          hintText: "Creative Development Lead",
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildList02(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Company",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 7.v),
        CustomTextFormField(
          controller: nameController,
          hintText: "Enter company name",
          hintStyle: CustomTextStyles.bodyLargeBluegray400,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildList03(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Location",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 9.v),
        CustomTextFormField(
          controller: locationController,
          hintText: "Enter company location",
          hintStyle: CustomTextStyles.bodyLargeBluegray400,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildBackground(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: CustomCheckboxButton(
        alignment: Alignment.centerLeft,
        text: "I am currently working here",
        value: background,
        padding: EdgeInsets.symmetric(vertical: 1.v),
        textStyle: CustomTextStyles.bodyMedium15,
        onChange: (value) {
          background = value;
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildRowStartDate(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: 8.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Start Date",
                  style: CustomTextStyles.titleMediumSemiBold,
                ),
                SizedBox(height: 9.v),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.h,
                    vertical: 11.v,
                  ),
                  decoration: AppDecoration.fillBlueGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder8,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: Text(
                          "DD/MM/YYYY",
                          style: CustomTextStyles.bodyLargeBluegray400,
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "End Date",
                  style: CustomTextStyles.titleMediumSemiBold,
                ),
                SizedBox(height: 9.v),
                CustomTextFormField(
                  width: 147.h,
                  controller: dateController,
                  hintText: "DD/MM/YYYY",
                  hintStyle: CustomTextStyles.bodyLargeBluegray400,
                  textInputAction: TextInputAction.done,
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildStackBackground(BuildContext context) {
    return SizedBox(
      height: 29.v,
      width: 311.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBackgroundPrimarycontainer,
            height: 29.v,
            width: 311.h,
            radius: BorderRadius.circular(
              8.h,
            ),
            alignment: Alignment.center,
          ),
          Align(
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconButton(
                  height: 20.adaptSize,
                  width: 20.adaptSize,
                  padding: EdgeInsets.all(5.h),
                  decoration: IconButtonStyleHelper.fillBlueTL10,
                  child: CustomImageView(
                    imagePath: ImageConstant.imgClosePrimarycontainer,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 8.h,
                    bottom: 3.v,
                  ),
                  child: Text(
                    "Add More",
                    style: CustomTextStyles.bodyMediumBluegray400_1,
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNext(BuildContext context) {
    return CustomElevatedButton(
      text: "Next",
      margin: EdgeInsets.only(
        left: 32.h,
        right: 32.h,
        bottom: 50.v,
      ),
      buttonTextStyle: theme.textTheme.headlineSmall!,
      onPressed: () {
        Navigator.pushNamed(context, AppRoutes.jobPreferencesScreen);
      },
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
