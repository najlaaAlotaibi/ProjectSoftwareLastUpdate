import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class SelectionsScreen extends StatelessWidget {
  const SelectionsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.blue200,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.all(1.h),
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgJobHuntingRemovebgPreview,
                height: 175.v,
                width: 273.h,
              ),
              SizedBox(height: 65.v),
              Text(
                " select page Type",
                style: theme.textTheme.headlineLarge,
              ),
              SizedBox(height: 10.v),
              Container(
                width: 295.h,
                margin: EdgeInsets.only(
                  left: 32.h,
                  right: 45.h,
                ),
                child: Text(
                  "Choose whether you are looking for \n a job or you are  a company needs\nemployee  ",
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: CustomTextStyles.titleMediumMontserratPrimaryContainer
                      .copyWith(
                    height: 1.50,
                  ),
                ),
              ),
              SizedBox(height: 67.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 47.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 15.h,
                        vertical: 7.v,
                      ),
                      decoration: AppDecoration.outlinePrimary.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder8,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgBag,
                            height: 24.adaptSize,
                            width: 24.adaptSize,
                            alignment: Alignment.centerRight,
                            margin: EdgeInsets.only(right: 30.h),
                          ),
                          SizedBox(height: 2.v),
                          Text(
                            "Find a  job",
                            style: CustomTextStyles
                                .labelLargeMontserratPrimaryContainer,
                          ),
                          SizedBox(height: 4.v),
                          SizedBox(
                            width: 86.h,
                            child: Text(
                              "I want to Find \na job for me",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: CustomTextStyles
                                  .labelLargeMontserratAlternatesPrimaryContainer
                                  .copyWith(
                                height: 1.50,
                              ),
                            ),
                          ),
                          SizedBox(height: 15.v)
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 31.h),
                      padding: EdgeInsets.symmetric(
                        horizontal: 5.h,
                        vertical: 4.v,
                      ),
                      decoration: AppDecoration.outlineGray.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder8,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgLock,
                            height: 24.v,
                            width: 26.h,
                          ),
                          SizedBox(height: 4.v),
                          SizedBox(
                            width: 63.h,
                            child: Text(
                              "Find an \nemployee",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: CustomTextStyles
                                  .labelLargeMontserratBluegray100af
                                  .copyWith(
                                height: 1.50,
                              ),
                            ),
                          ),
                          SizedBox(height: 8.v),
                          SizedBox(
                            width: 106.h,
                            child: Text(
                              "I want to Find an\nemployee",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: CustomTextStyles
                                  .labelLargeMontserratAlternatesBluegray5001
                                  .copyWith(
                                height: 1.50,
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Spacer(),
              SizedBox(height: 64.v),
              CustomElevatedButton(
                height: 54.v,
                text: "Next",
                margin: EdgeInsets.symmetric(horizontal: 44.h),
                buttonStyle: CustomButtonStyles.fillPrimary,
                buttonTextStyle: CustomTextStyles.headlineLargePonnala,
                onPressed: () {
                  Navigator.of(context).pushNamed(AppRoutes.loginScreen);
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
