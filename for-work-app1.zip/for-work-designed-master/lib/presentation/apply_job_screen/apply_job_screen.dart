import 'package:flutter/material.dart';
import 'package:dotted_border/dotted_border.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'widgets/chipviewno_item_widget.dart';
import 'widgets/chipviewnone_item_widget.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ApplyJobScreen extends StatelessWidget {
  ApplyJobScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController writeyourController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildColumnArrowLeft(context),
              SizedBox(height: 27.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    margin: EdgeInsets.only(bottom: 5.v),
                    padding: EdgeInsets.symmetric(horizontal: 16.h),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Add Cover Letter",
                          style: theme.textTheme.titleMedium,
                        ),
                        SizedBox(height: 12.v),
                        CustomTextFormField(
                          controller: writeyourController,
                          hintText: "Write your letter",
                          hintStyle: CustomTextStyles.bodyLargeBluegray400,
                          textInputAction: TextInputAction.done,
                          maxLines: 5,
                        ),
                        SizedBox(height: 29.v),
                        Text(
                          "Upload Resume",
                          style: theme.textTheme.titleMedium,
                        ),
                        SizedBox(height: 10.v),
                        _buildRowTwitterOne(context),
                        SizedBox(height: 8.v),
                        Container(
                          width: 262.h,
                          margin: EdgeInsets.only(right: 80.h),
                          child: Text(
                            "Upload your CV/resume or any other relevant. Max. file size: 30MB.",
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: CustomTextStyles.bodyMediumBluegray400_1
                                .copyWith(
                              height: 1.38,
                            ),
                          ),
                        ),
                        SizedBox(height: 29.v),
                        _buildList03(context),
                        SizedBox(height: 27.v),
                        Text(
                          "Your Education",
                          style: theme.textTheme.titleMedium,
                        ),
                        SizedBox(height: 20.v),
                        _buildChipViewNone(context)
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        bottomNavigationBar: _buildSendNow(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnArrowLeft(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10.v),
      decoration: AppDecoration.fillGray50,
      child: Column(
        children: [
          CustomAppBar(
            height: 22.v,
            leadingWidth: 21.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgArrowLeft,
              margin: EdgeInsets.only(left: 9.h),
              onTap: () {
                onTapArrowleftone(context);
              },
            ),
            centerTitle: true,
            title: AppbarSubtitleTwo(
              text: "Apply",
            ),
            actions: [
              AppbarSubtitle(
                text: "Cancel",
                margin: EdgeInsets.only(
                  left: 16.h,
                  right: 16.h,
                  bottom: 2.v,
                ),
              )
            ],
          ),
          SizedBox(height: 18.v),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 16.h),
            padding: EdgeInsets.all(15.h),
            decoration: AppDecoration.outlineBluegray501.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder8,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: 45.adaptSize,
                  padding: EdgeInsets.symmetric(
                    horizontal: 9.h,
                    vertical: 16.v,
                  ),
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder22,
                  ),
                  child: Text(
                    "45 x 45",
                    style: theme.textTheme.labelSmall,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 4.v,
                    bottom: 2.v,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Product Designer",
                        style: theme.textTheme.titleSmall,
                      ),
                      SizedBox(height: 2.v),
                      SizedBox(
                        width: 187.h,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(bottom: 1.v),
                              child: Text(
                                "Limited Sounds",
                                style: theme.textTheme.bodyMedium,
                              ),
                            ),
                            Container(
                              height: 2.adaptSize,
                              width: 2.adaptSize,
                              margin: EdgeInsets.symmetric(vertical: 7.v),
                              decoration: BoxDecoration(
                                color: appTheme.blueGray400,
                                borderRadius: BorderRadius.circular(
                                  1.h,
                                ),
                              ),
                            ),
                            Text(
                              "349 Irvine, CA",
                              style: theme.textTheme.bodyMedium,
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          SizedBox(height: 5.v)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowTwitterOne(BuildContext context) {
    return Container(
      decoration: AppDecoration.outlineGray4001.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: DottedBorder(
        color: appTheme.gray400,
        padding: EdgeInsets.only(
          left: 2.h,
          top: 2.v,
          right: 2.h,
          bottom: 2.v,
        ),
        strokeWidth: 2.h,
        radius: Radius.circular(8),
        borderType: BorderType.RRect,
        dashPattern: [3, 8],
        child: Padding(
          padding: EdgeInsets.all(14.h),
          child: Row(
            children: [
              CustomIconButton(
                height: 40.adaptSize,
                width: 40.adaptSize,
                padding: EdgeInsets.all(12.h),
                decoration: IconButtonStyleHelper.fillBlueGray,
                child: CustomImageView(
                  imagePath: ImageConstant.imgTwitterBlueGray400,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Upload",
                      style: theme.textTheme.titleSmall,
                    ),
                    SizedBox(height: 3.v),
                    Text(
                      ".pdf, .doc, .txt, .rtf accepted",
                      style: theme.textTheme.bodyMedium,
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildList03(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Your Experience",
          style: theme.textTheme.titleMedium,
        ),
        SizedBox(height: 18.v),
        Wrap(
          runSpacing: 8.v,
          spacing: 8.h,
          children: List<Widget>.generate(6, (index) => ChipviewnoItemWidget()),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildChipViewNone(BuildContext context) {
    return Wrap(
      runSpacing: 8.v,
      spacing: 8.h,
      children: List<Widget>.generate(6, (index) => ChipviewnoneItemWidget()),
    );
  }

  /// Section Widget
  Widget _buildSendNow(BuildContext context) {
    return CustomElevatedButton(
      text: "Send Now",
      margin: EdgeInsets.only(
        left: 16.h,
        right: 16.h,
        bottom: 50.v,
      ),
      buttonStyle: CustomButtonStyles.fillBlue,
      buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
