import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_search_view.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ChooseLocationScreen extends StatelessWidget {
  ChooseLocationScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray400,
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: Column(
            children: [
              CustomSearchView(
                controller: searchController,
                hintText: "Type location you want…",
              ),
              Spacer(
                flex: 44,
              ),
              SizedBox(
                height: 81.v,
                width: 184.h,
                child: Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: SizedBox(
                        height: 57.v,
                        width: 184.h,
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            Align(
                              alignment: Alignment.center,
                              child: Text(
                                "375 x 812",
                                style: theme.textTheme.displayMedium,
                              ),
                            ),
                            CustomImageView(
                              imagePath: ImageConstant.imgLinkedinRedA400,
                              height: 32.v,
                              width: 26.h,
                              alignment: Alignment.bottomCenter,
                              margin: EdgeInsets.only(bottom: 10.v),
                            )
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topCenter,
                      child: SizedBox(
                        height: 35.v,
                        width: 125.h,
                        child: Stack(
                          alignment: Alignment.topCenter,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgBackground,
                              height: 35.v,
                              width: 125.h,
                              alignment: Alignment.center,
                            ),
                            Align(
                              alignment: Alignment.topCenter,
                              child: Padding(
                                padding: EdgeInsets.only(top: 5.v),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      "Set Location",
                                      style: CustomTextStyles
                                          .titleSmallPrimaryContainer,
                                    ),
                                    CustomImageView(
                                      imagePath: ImageConstant.imgArrowRight,
                                      height: 9.v,
                                      width: 6.h,
                                      margin: EdgeInsets.only(
                                        left: 14.h,
                                        top: 5.v,
                                        bottom: 3.v,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Spacer(
                flex: 55,
              ),
              SizedBox(height: 58.v),
              CustomIconButton(
                height: 56.adaptSize,
                width: 56.adaptSize,
                padding: EdgeInsets.all(16.h),
                decoration: IconButtonStyleHelper.outlineBlack,
                alignment: Alignment.centerRight,
                child: CustomImageView(
                  imagePath: ImageConstant.imgContrast,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 12.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarSubtitleTwo(
        text: "Your Location",
      ),
      styleType: Style
          .bgGradientnameprimaryContaineropacity1nameprimaryContaineropacity0,
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
