import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:for_work_application1/core/view_model/auth_view_model.dart';
import 'package:for_work_application1/presentation/login_screen/login_screen.dart';
import 'package:get/get.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart';

class SignUpScreen extends GetWidget<AuthViewModel> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  SignUpScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SizedBox(
              height: SizeUtils.height,
              child: Form(
                key: _formKey,
                child: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(
                    horizontal: 32.h,
                    vertical: 58.v,
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 15.v),
                      _buildWelcomeUserSection(context),
                      SizedBox(height: 40.v),
                      _buildNameSection(context),
                      SizedBox(height: 8.v),
                      _buildEmailSection(context),
                      SizedBox(height: 8.v),
                      _buildPasswordSection(context),
                      SizedBox(height: 8.v),
                      _buildMobileLabelOneSection(context),
                      SizedBox(height: 24.v),
                      _buildIAgreeToTheTermSection(context),
                      SizedBox(height: 24.v),
                      GetX<AuthViewModel>(
                        builder: (process) => process.action.value
                            ? const Center(
                                child: CupertinoActivityIndicator(),
                              )
                            : _buildSignUpSection(context),
                      ),
                      Spacer(),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: "Have an account? ",
                                style: CustomTextStyles.bodyLargeGray700,
                              ),
                              TextSpan(
                                text: "Sign In",
                                style: CustomTextStyles.titleMediumMedium,
                              )
                            ],
                          ),
                          textAlign: TextAlign.left,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildWelcomeUserSection(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 167.h,
              child: Text(
                "Welcome user",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: CustomTextStyles.displayMediumBlack90001,
              ),
            ),
            SizedBox(height: 20.v),
            Text(
              "Sign up to join",
              style: CustomTextStyles.bodyLargeGray700_1,
            )
          ],
        ),
        Container(
          margin: EdgeInsets.symmetric(vertical: 24.v),
          decoration: AppDecoration.fillGray.copyWith(
            borderRadius: BorderRadiusStyle.circleBorder43,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 32.v),
              Text(
                "86 x 86",
                style: CustomTextStyles.titleMediumBluegray400SemiBold,
              ),
              SizedBox(height: 1.v),
              CustomIconButton(
                height: 32.adaptSize,
                width: 32.adaptSize,
                padding: EdgeInsets.all(10.h),
                decoration: IconButtonStyleHelper.fillBlue,
                alignment: Alignment.centerRight,
                child: CustomImageView(
                  imagePath: ImageConstant.imgGrid,
                ),
              )
            ],
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildNameSection(BuildContext context) {
    return CustomTextFormField(
      onSaved: (value) {
        controller.name = value!;
      },
      validator: (value) {
        if (controller.name.isEmpty) {
          return "This field is required";
        }
        return null;
      },
      hintText: "Name",
      hintStyle: CustomTextStyles.bodyLargeBluegray400,
    );
  }

  /// Section Widget
  Widget _buildEmailSection(BuildContext context) {
    return CustomTextFormField(
      hintText: "Email",
      onSaved: (value) {
        controller.email = value!;
      },
      validator: (value) {
        final regex = RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$');
        if (controller.email.isEmpty) {
          return 'Please, Enter your Email';
        } else if (!regex.hasMatch(value!)) {
          return 'Your Email is not valid';
        }
        return null;
      },
      hintStyle: CustomTextStyles.bodyLargeBluegray400,
      textInputType: TextInputType.emailAddress,
    );
  }

  /// Section Widget
  Widget _buildPasswordSection(BuildContext context) {
    return CustomTextFormField(
      hintText: "Password",
      onSaved: (value) {
        controller.password = value!;
      },
      validator: (value) {
        if (controller.password.isEmpty) {
          return "This field is required";
        }
        return null;
      },
      hintStyle: CustomTextStyles.bodyLargeBluegray400,
      textInputType: TextInputType.visiblePassword,
      obscureText: true,
    );
  }

  /// Section Widget
  Widget _buildMobileLabelOneSection(BuildContext context) {
    return CustomTextFormField(
      hintText: "Mobile",
      onSaved: (value) {
        controller.phone = value!;
      },
      validator: (value) {
        if (controller.phone.isEmpty) {
          return "This field is required";
        }
        return null;
      },
      hintStyle: CustomTextStyles.bodyLargeBluegray400,
      textInputAction: TextInputAction.done,
      textInputType: TextInputType.phone,
    );
  }

  /// Section Widget
  Widget _buildIAgreeToTheTermSection(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(right: 77.h),
        child: GetX<AuthViewModel>(
          builder: (authCtrl) {
            return CustomCheckboxButton(
              alignment: Alignment.centerLeft,
              text: "I agree to the Terms of Service",
              value: authCtrl.agreeTerms.value,
              padding: EdgeInsets.symmetric(vertical: 1.v),
              textStyle: CustomTextStyles.bodyMedium15,
              onChange: (value) {
                authCtrl.changeAgree();
              },
            );
          },
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSignUpSection(BuildContext context) {
    return CustomElevatedButton(
      text: "Sign Up",
      buttonStyle: CustomButtonStyles.fillBlue,
      buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
      onPressed: () async {
        _formKey.currentState!.save();
        if (controller.agreeTerms.value) {
          if (_formKey.currentState!.validate()) {
            await controller.createAccountWithEmailAndPassword();
            Get.offAll(() => LoginScreen());
            Get.put(AuthViewModel());
          }
        } else {
          Get.snackbar(
            'Error',
            "You must accept and agree Terms",
            snackPosition: SnackPosition.TOP,
            colorText: Colors.red,
          );
        }
      },
    );
  }
}
