import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_title_searchview.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../search_page/search_page.dart';

class SearchTabContainerScreen extends StatefulWidget {
  const SearchTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  @override
  SearchTabContainerScreenState createState() =>
      SearchTabContainerScreenState();
}
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class SearchTabContainerScreenState extends State<SearchTabContainerScreen>
    with TickerProviderStateMixin {
  TextEditingController searchController = TextEditingController();

  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildTabview(context),
              SizedBox(
                height: 672.v,
                child: TabBarView(
                  controller: tabviewController,
                  children: [
                    SearchPage(),
                    SearchPage(),
                    SearchPage(),
                    SearchPage()
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 52.v,
      title: AppbarTitleSearchview(
        margin: EdgeInsets.only(left: 16.h),
        hintText: "Search",
        controller: searchController,
      ),
      actions: [
        AppbarSubtitle(
          text: "Cancel",
          margin: EdgeInsets.fromLTRB(11.h, 15.v, 16.h, 16.v),
        )
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildTabview(BuildContext context) {
    return Container(
      height: 44.v,
      width: double.maxFinite,
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withOpacity(1),
        boxShadow: [
          BoxShadow(
            color: appTheme.blueGray50,
            spreadRadius: 2.h,
            blurRadius: 2.h,
            offset: Offset(
              0,
              1,
            ),
          )
        ],
      ),
      child: TabBar(
        controller: tabviewController,
        isScrollable: true,
        labelColor: appTheme.black90001,
        labelStyle: TextStyle(
          fontSize: 15.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w500,
        ),
        unselectedLabelColor: appTheme.blueGray400,
        unselectedLabelStyle: TextStyle(
          fontSize: 15.fSize,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
        ),
        indicatorColor: appTheme.blue700,
        tabs: [
          Tab(
            child: Text(
              "All Categories",
            ),
          ),
          Tab(
            child: Text(
              "Developer",
            ),
          ),
          Tab(
            child: Text(
              "Banking",
            ),
          ),
          Tab(
            child: Text(
              "Engineer",
            ),
          )
        ],
      ),
    );
  }
}
