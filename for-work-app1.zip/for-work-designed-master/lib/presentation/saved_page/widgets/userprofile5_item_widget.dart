import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class Userprofile5ItemWidget extends StatelessWidget {
  const Userprofile5ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 15.h,
        vertical: 16.v,
      ),
      decoration: AppDecoration.outlineBluegray501.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 45.adaptSize,
            margin: EdgeInsets.only(
              top: 6.v,
              bottom: 5.v,
            ),
            padding: EdgeInsets.symmetric(
              horizontal: 9.h,
              vertical: 16.v,
            ),
            decoration: AppDecoration.fillGray.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder22,
            ),
            child: Text(
              "45 x 45",
              style: theme.textTheme.labelSmall,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Product Designer",
                  style: theme.textTheme.titleSmall,
                ),
                SizedBox(height: 2.v),
                SizedBox(
                  width: 197.h,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: 1.v),
                        child: Text(
                          "Limited Sounds",
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                      Container(
                        height: 2.adaptSize,
                        width: 2.adaptSize,
                        margin: EdgeInsets.symmetric(vertical: 7.v),
                        decoration: BoxDecoration(
                          color: appTheme.blueGray400,
                          borderRadius: BorderRadius.circular(
                            1.h,
                          ),
                        ),
                      ),
                      Text(
                        "349 Fintas , KW",
                        style: theme.textTheme.bodyMedium,
                      )
                    ],
                  ),
                ),
                SizedBox(height: 3.v),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Fulltime",
                      style: CustomTextStyles.bodyMediumBluegray400_1,
                    ),
                    Container(
                      height: 2.adaptSize,
                      width: 2.adaptSize,
                      margin: EdgeInsets.only(
                        left: 7.h,
                        top: 7.v,
                        bottom: 6.v,
                      ),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray400,
                        borderRadius: BorderRadius.circular(
                          1.h,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.h),
                      child: Text(
                        "KD8K/mo",
                        style: CustomTextStyles.bodyMediumBlack90001,
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgBookmarkGreen700,
            height: 20.v,
            width: 15.h,
            margin: EdgeInsets.only(
              top: 19.v,
              bottom: 17.v,
            ),
          )
        ],
      ),
    );
  }
}
