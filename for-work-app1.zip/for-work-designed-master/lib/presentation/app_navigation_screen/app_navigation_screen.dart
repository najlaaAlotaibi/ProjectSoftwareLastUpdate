import 'package:flutter/material.dart';
import '../../core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: AppDecoration.fillPrimaryContainer,
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "Splash Screen",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.splashScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "get Started",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.getStartedScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "selections",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.selectionsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Login",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.loginScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Login error email",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.loginErrorEmailScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Login error password",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.loginErrorPasswordScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "08-Sign-Up",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.signUpScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "10-Set-Location",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.setLocationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "11-Choose-Location",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.chooseLocationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "13-Personal-Information",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.personalInformationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "19-Browse-One - Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.browseOneContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "24-Search - Tab Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.searchTabContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "26-Job-Details-One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.jobDetailsOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "28-Company-Details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.companyDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "14-Location",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.locationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "15-Education",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.educationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "16-Experience",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.experienceScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "17-Job-Preferences",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.jobPreferencesScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "23-Categories",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.categoriesScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "25-Filter",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.filterScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "29-Apply-Job",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.applyJobScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "32-Applied-Job-Details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.appliedJobDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "34-Message-Details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.messageDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "34-Message-Details One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.messageDetailsOneScreen),
                        )
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: AppDecoration.fillPrimaryContainer,
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: appTheme.black90001,
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: appTheme.blueGray40003,
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: appTheme.black90001,
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle?.call();
      },
      child: Container(
        decoration: AppDecoration.fillPrimaryContainer,
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: appTheme.black90001,
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: appTheme.blueGray40003,
            )
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
