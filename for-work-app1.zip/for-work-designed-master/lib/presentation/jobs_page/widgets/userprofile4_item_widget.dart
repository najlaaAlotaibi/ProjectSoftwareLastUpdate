import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class Userprofile4ItemWidget extends StatelessWidget {
  const Userprofile4ItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15.h),
      decoration: AppDecoration.outlineBluegray501.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 45.adaptSize,
            margin: EdgeInsets.only(bottom: 23.v),
            padding: EdgeInsets.symmetric(
              horizontal: 9.h,
              vertical: 16.v,
            ),
            decoration: AppDecoration.fillGray.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder22,
            ),
            child: Text(
              "45 x 45",
              style: theme.textTheme.labelSmall,
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgIconMoreBlueGray400,
                    height: 4.v,
                    width: 16.h,
                    alignment: Alignment.centerRight,
                  ),
                  Text(
                    "3D Animator",
                    style: theme.textTheme.titleSmall,
                  ),
                  SizedBox(height: 5.v),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(bottom: 1.v),
                        child: Text(
                          "Best Studio",
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                      Container(
                        height: 2.adaptSize,
                        width: 2.adaptSize,
                        margin: EdgeInsets.only(
                          left: 9.h,
                          top: 7.v,
                          bottom: 7.v,
                        ),
                        decoration: BoxDecoration(
                          color: appTheme.blueGray400,
                          borderRadius: BorderRadius.circular(
                            1.h,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.h),
                        child: Text(
                          "349 Mirqab, KW",
                          style: theme.textTheme.bodyMedium,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 8.v),
                  Container(
                    width: 201.h,
                    padding: EdgeInsets.symmetric(
                      horizontal: 8.h,
                      vertical: 1.v,
                    ),
                    decoration: AppDecoration.fillDeepPurpleA.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder8,
                    ),
                    child: Text(
                      "Interview on 09/29/24 at 11:15",
                      style: CustomTextStyles.bodyMediumPrimaryContainer,
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
