import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import 'widgets/userprofile4_item_widget.dart'; // ignore_for_file: must_be_immutable

class JobsPage extends StatefulWidget {
  const JobsPage({Key? key})
      : super(
          key: key,
        );

  @override
  JobsPageState createState() => JobsPageState();
}

class JobsPageState extends State<JobsPage>
    with AutomaticKeepAliveClientMixin<JobsPage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray50,
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillGray50,
          child: SingleChildScrollView(
            child: Column(
              children: [SizedBox(height: 16.v), _buildUserProfile(context)],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfile(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 4.v,
          );
        },
        itemCount: 4,
        itemBuilder: (context, index) {
          return Userprofile4ItemWidget();
        },
      ),
    );
  }
}
