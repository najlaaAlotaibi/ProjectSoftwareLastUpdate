import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_search_view.dart';
import 'widgets/userprofile_item_widget.dart';
import 'widgets/userprofilelist_item_widget.dart'; // ignore_for_file: must_be_immutable
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class BrowseOnePage extends StatelessWidget {
  BrowseOnePage({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  int sliderIndex = 1;

  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillPrimaryContainer,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildFindYourDreamAppBar(context),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16.h),
                  child: Column(
                    children: [
                      SizedBox(height: 10.v),
                      _buildRecentPosts(context),
                      SizedBox(height: 10.v),
                      _buildBestMatchRow(context),
                      SizedBox(height: 10.v),
                      _buildUserProfileList(context)
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFindYourDreamAppBar(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 11.v),
      decoration: AppDecoration.outlineBlueGray,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 15.v),
          CustomAppBar(
            height: 33.v,
            title: AppbarTitle(
              text: "Find your dream job in",
              margin: EdgeInsets.only(left: 16.h),
            ),
          ),
          SizedBox(height: 11.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Al Ahmadi, Kuwait?",
                    style: CustomTextStyles.titleLargeRoboto,
                  ),
                  CustomImageView(
                    imagePath: ImageConstant.imgArrowDownBlack90001,
                    height: 8.v,
                    width: 13.h,
                    margin: EdgeInsets.only(
                      left: 18.h,
                      top: 7.v,
                      bottom: 10.v,
                    ),
                  )
                ],
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: SizedBox(
              width: 239.h,
              child: Divider(
                color: appTheme.black90001,
                indent: 16.h,
              ),
            ),
          ),
          SizedBox(height: 16.v),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            child: CustomSearchView(
              controller: searchController,
              hintText: "Search for everything…",
            ),
          ),
          SizedBox(height: 21.v),
          SizedBox(
            height: 18.v,
            child: Padding(
              padding: EdgeInsets.only(left: 12.h),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  SizedBox(
                    width: 95.h,
                    child: Text(
                      "All Categories",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 14.fSize,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 16.h,
                  ),
                  SizedBox(
                    width: 95.h,
                    child: Text(
                      "Developer",
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontWeight: FontWeight.w400,
                        fontSize: 14.fSize,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 8.h,
                  ),
                  SizedBox(
                    width: 95.h,
                    child: Text(
                      "Banking",
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontWeight: FontWeight.w400,
                        fontSize: 14.fSize,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 8.h,
                  ),
                  SizedBox(
                    width: 95.h,
                    child: Text(
                      "Engineer",
                      style: TextStyle(
                        color: Colors.grey[300],
                        fontWeight: FontWeight.w400,
                        fontSize: 14.fSize,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRecentPosts(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Recent Posts",
          style: theme.textTheme.titleMedium,
        ),
        SizedBox(height: 8.v),
        SizedBox(
          height: 190.v,
          width: 343.h,
          child: Stack(
            alignment: Alignment.bottomLeft,
            children: [
              CarouselSlider.builder(
                options: CarouselOptions(
                  height: 190.v,
                  initialPage: 0,
                  autoPlay: true,
                  viewportFraction: 1.0,
                  enableInfiniteScroll: false,
                  scrollDirection: Axis.horizontal,
                  onPageChanged: (index, reason) {
                    sliderIndex = index;
                  },
                ),
                itemCount: 1,
                itemBuilder: (context, index, realIndex) {
                  return UserprofileItemWidget();
                },
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  height: 7.v,
                  margin: EdgeInsets.only(
                    left: 16.h,
                    bottom: 16.v,
                  ),
                  child: AnimatedSmoothIndicator(
                    activeIndex: sliderIndex,
                    count: 1,
                    axisDirection: Axis.horizontal,
                    effect: ScrollingDotsEffect(
                      spacing: 8,
                      activeDotColor: appTheme.blue700,
                      dotColor: appTheme.gray700.withOpacity(0.49),
                      dotHeight: 7.v,
                      dotWidth: 7.h,
                    ),
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildBestMatchRow(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 15.h),
      decoration: AppDecoration.outlineBluegray50.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomDropDown(
            width: 137.h,
            icon: Container(
              margin: EdgeInsets.symmetric(horizontal: 22.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgArrowdown,
                height: 5.v,
                width: 8.h,
              ),
            ),
            hintText: "Best Match",
            hintStyle: CustomTextStyles.bodyMedium15,
            items: dropdownItemList,
            contentPadding: EdgeInsets.only(
              top: 12.v,
              bottom: 13.v,
            ),
            borderDecoration: DropDownStyleHelper.custom,
            filled: false,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgShare,
            height: 16.v,
            width: 13.h,
            margin: EdgeInsets.only(
              left: 21.h,
              top: 14.v,
              bottom: 14.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 8.h,
              top: 12.v,
              bottom: 13.v,
            ),
            child: Text(
              "Sort",
              style: CustomTextStyles.bodyMedium15,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 24.h),
            child: SizedBox(
              height: 44.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgFilter,
            height: 12.v,
            width: 14.h,
            margin: EdgeInsets.only(
              left: 21.h,
              top: 16.v,
              bottom: 14.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 8.h,
              top: 12.v,
              bottom: 13.v,
            ),
            child: Text(
              "Filter",
              style: CustomTextStyles.bodyMedium15,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList(BuildContext context) {
    return ListView.separated(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      separatorBuilder: (context, index) {
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 4.5.v),
          child: SizedBox(
            width: 282.h,
            child: Divider(
              height: 1.v,
              thickness: 1.v,
              color: appTheme.blueGray50,
            ),
          ),
        );
      },
      itemCount: 4,
      itemBuilder: (context, index) {
        return UserprofilelistItemWidget();
      },
    );
  }
}
