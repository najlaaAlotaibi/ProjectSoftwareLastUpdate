import 'package:flutter/material.dart';

import '../../../core/app_export.dart'; // ignore: must_be_immutable

class CategoriesItemWidget extends StatelessWidget {
  const CategoriesItemWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 95.h,
      child: Text(
        "All Categories",
        style: CustomTextStyles.titleSmallPrimaryContainer,
      ),
    );
  }
}
