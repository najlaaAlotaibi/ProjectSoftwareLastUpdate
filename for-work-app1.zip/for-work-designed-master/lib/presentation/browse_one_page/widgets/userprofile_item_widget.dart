import 'package:flutter/material.dart';
import '../../../core/app_export.dart'; // ignore: must_be_immutable

class UserprofileItemWidget extends StatelessWidget {
  const UserprofileItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: Container(
        padding: EdgeInsets.all(16.h),
        decoration: AppDecoration.fillBlueGray.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 45.adaptSize,
                  padding: EdgeInsets.symmetric(
                    horizontal: 9.h,
                    vertical: 16.v,
                  ),
                  decoration: AppDecoration.fillGray.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder22,
                  ),
                  child: Text(
                    "45 x 45",
                    style: theme.textTheme.labelSmall,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 14.v,
                    bottom: 14.v,
                  ),
                  child: Text(
                    "Kuwait National co. ",
                    style: theme.textTheme.labelLarge,
                  ),
                ),
                Spacer(),
                CustomImageView(
                  imagePath: ImageConstant.imgBookmark,
                  height: 20.v,
                  width: 15.h,
                  margin: EdgeInsets.only(bottom: 25.v),
                )
              ],
            ),
            SizedBox(height: 9.v),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 1.v),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Electrical Engineeer",
                        style: CustomTextStyles.titleMediumMedium_1,
                      ),
                      SizedBox(height: 5.v),
                      Text(
                        "Safat 13030. Kuwait City",
                        style: theme.textTheme.bodyMedium,
                      )
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "KD2K/mo",
                      style: CustomTextStyles.titleMediumMedium_1,
                    ),
                    SizedBox(height: 6.v),
                    Text(
                      "1hour ago",
                      style: theme.textTheme.bodyMedium,
                    )
                  ],
                )
              ],
            ),
            SizedBox(height: 31.v)
          ],
        ),
      ),
    );
  }
}
