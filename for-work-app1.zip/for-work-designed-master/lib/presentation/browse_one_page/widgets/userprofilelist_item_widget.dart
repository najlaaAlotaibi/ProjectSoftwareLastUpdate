import 'package:flutter/material.dart';

import '../../../core/app_export.dart'; // ignore: must_be_immutable

class UserprofilelistItemWidget extends StatelessWidget {
  const UserprofilelistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 45.adaptSize,
          margin: EdgeInsets.only(
            top: 6.v,
            bottom: 5.v,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: 9.h,
            vertical: 16.v,
          ),
          decoration: AppDecoration.fillGray.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder22,
          ),
          child: Text(
            "45 x 45",
            style: theme.textTheme.labelSmall,
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 10.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Product Designer",
                  style: theme.textTheme.titleSmall,
                ),
                SizedBox(height: 1.v),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 1.v),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(bottom: 1.v),
                                child: Text(
                                  "Creatio Studio",
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              Container(
                                height: 2.adaptSize,
                                width: 2.adaptSize,
                                margin: EdgeInsets.only(
                                  left: 11.h,
                                  top: 7.v,
                                  bottom: 7.v,
                                ),
                                decoration: BoxDecoration(
                                  color: appTheme.blueGray400,
                                  borderRadius: BorderRadius.circular(
                                    1.h,
                                  ),
                                ),
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgLinkedinGray400,
                                height: 12.v,
                                width: 10.h,
                                margin: EdgeInsets.only(
                                  left: 5.h,
                                  top: 2.v,
                                  bottom: 1.v,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 8.h),
                                child: Text(
                                  "349 Kuwait city",
                                  style: theme.textTheme.bodyMedium,
                                ),
                              )
                            ],
                          ),
                          SizedBox(height: 2.v),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Fulltime",
                                style: CustomTextStyles.bodyMediumBluegray400_1,
                              ),
                              Container(
                                height: 2.adaptSize,
                                width: 2.adaptSize,
                                margin: EdgeInsets.only(
                                  left: 7.h,
                                  top: 7.v,
                                  bottom: 6.v,
                                ),
                                decoration: BoxDecoration(
                                  color: appTheme.blueGray400,
                                  borderRadius: BorderRadius.circular(
                                    1.h,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 5.h),
                                child: Text(
                                  "KD1200K/mo",
                                  style: CustomTextStyles.bodyMediumBlack90001,
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgBookmarkGreen700,
                      height: 20.v,
                      width: 15.h,
                      margin: EdgeInsets.only(
                        left: 61.h,
                        bottom: 17.v,
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        )
      ],
    );
  }
}
