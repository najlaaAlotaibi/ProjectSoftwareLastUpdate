import 'package:flutter/material.dart';
import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_pickers.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_phone_number.dart';
import '../../widgets/custom_radio_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'widgets/chipviewdevelop_item_widget.dart';
import 'widgets/chipviewentry_item_widget.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class FilterScreen extends StatelessWidget {
  FilterScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController linkedinController = TextEditingController();

  String radioGroup = "";

  String radioGroup1 = "";

  Country selectedCountry = CountryPickerUtils.getCountryByPhoneCode('1');

  TextEditingController phoneNumberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildAppBar(context),
              SizedBox(height: 8.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16.h),
                          child: CustomTextFormField(
                            controller: linkedinController,
                            hintText: "Al Ahmadi, Kuwait",
                            hintStyle: CustomTextStyles.bodyMediumBlack9000115,
                            prefix: Container(
                              margin:
                                  EdgeInsets.fromLTRB(16.h, 15.v, 8.h, 15.v),
                              child: CustomImageView(
                                imagePath:
                                    ImageConstant.imgLinkedinRedA40020x16,
                                height: 20.v,
                                width: 16.h,
                              ),
                            ),
                            prefixConstraints: BoxConstraints(
                              maxHeight: 50.v,
                            ),
                            suffix: Container(
                              margin:
                                  EdgeInsets.fromLTRB(30.h, 15.v, 16.h, 15.v),
                              child: CustomImageView(
                                imagePath: ImageConstant.imgContrastBlueGray400,
                                height: 20.adaptSize,
                                width: 20.adaptSize,
                              ),
                            ),
                            suffixConstraints: BoxConstraints(
                              maxHeight: 50.v,
                            ),
                            contentPadding:
                                EdgeInsets.symmetric(vertical: 16.v),
                          ),
                        ),
                        SizedBox(height: 27.v),
                        _buildDistance(context),
                        SizedBox(height: 29.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "Job Type",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 22.v),
                        _buildRowFullTime(context),
                        SizedBox(height: 12.v),
                        _buildPartTime(context),
                        SizedBox(height: 11.v),
                        _buildRowContract(context),
                        SizedBox(height: 12.v),
                        _buildInternship(context),
                        SizedBox(height: 11.v),
                        _buildRowFreelance(context),
                        SizedBox(height: 12.v),
                        Divider(
                          indent: 16.h,
                        ),
                        SizedBox(height: 29.v),
                        _buildCategories(context),
                        SizedBox(height: 29.v),
                        _buildSalaryRange(context),
                        SizedBox(height: 29.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "Experience Level",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 18.v),
                        _buildChipViewEntry(context),
                        SizedBox(height: 29.v),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: EdgeInsets.only(left: 16.h),
                            child: Text(
                              "Company Rating",
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                        ),
                        SizedBox(height: 10.v),
                        _buildRowone(context)
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        bottomNavigationBar: _buildApplyFilters(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 9.v),
      decoration: AppDecoration.fillPrimaryContainer,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 1.v),
          CustomAppBar(
            height: 21.v,
            leadingWidth: 21.h,
            leading: AppbarLeadingImage(
              imagePath: ImageConstant.imgArrowLeft,
              margin: EdgeInsets.only(left: 9.h),
              onTap: () {
                onTapArrowleftone(context);
              },
            ),
            actions: [
              AppbarSubtitle(
                text: "Reset",
                margin: EdgeInsets.symmetric(horizontal: 16.h),
              )
            ],
          ),
          SizedBox(height: 14.v),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Text(
              "Filter",
              style: theme.textTheme.displaySmall,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDistance(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Discover Jobs Near You",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 20.v),
          Padding(
            padding: EdgeInsets.only(right: 16.h),
            child: SliderTheme(
              data: SliderThemeData(
                trackShape: RoundedRectSliderTrackShape(),
                activeTrackColor: appTheme.blue700,
                inactiveTrackColor: appTheme.gray400,
                thumbColor: theme.colorScheme.primaryContainer.withOpacity(1),
                thumbShape: RoundSliderThumbShape(),
              ),
              child: RangeSlider(
                values: RangeValues(
                  0,
                  0,
                ),
                min: 0.0,
                max: 100.0,
                onChanged: (value) {},
              ),
            ),
          ),
          SizedBox(height: 7.v),
          Row(
            children: [
              Text(
                "0",
                style: CustomTextStyles.bodyMedium15,
              ),
              Padding(
                padding: EdgeInsets.only(left: 61.h),
                child: Text(
                  "100 miles",
                  style: CustomTextStyles.bodyMedium15,
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildRowFullTime(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Full Time",
            style: theme.textTheme.bodyLarge,
          ),
          Container(
            height: 20.adaptSize,
            width: 20.adaptSize,
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withOpacity(1),
              borderRadius: BorderRadius.circular(
                10.h,
              ),
              border: Border.all(
                color: appTheme.blueGray100,
                width: 1.h,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPartTime(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: CustomRadioButton(
        text: "Part Time",
        value: "Part Time",
        groupValue: radioGroup,
        padding: EdgeInsets.symmetric(vertical: 12.v),
        onChange: (value) {
          radioGroup = value;
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildRowContract(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Contract",
            style: theme.textTheme.bodyLarge,
          ),
          Container(
            height: 20.adaptSize,
            width: 20.adaptSize,
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withOpacity(1),
              borderRadius: BorderRadius.circular(
                10.h,
              ),
              border: Border.all(
                color: appTheme.blueGray100,
                width: 1.h,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildInternship(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: CustomRadioButton(
        width: 359.h,
        text: "Internship",
        value: "Internship",
        groupValue: radioGroup1,
        padding: EdgeInsets.symmetric(vertical: 11.v),
        isRightCheck: true,
        onChange: (value) {
          radioGroup1 = value;
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildRowFreelance(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Freelance",
            style: theme.textTheme.bodyLarge,
          ),
          Container(
            height: 20.adaptSize,
            width: 20.adaptSize,
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withOpacity(1),
              borderRadius: BorderRadius.circular(
                10.h,
              ),
              border: Border.all(
                color: appTheme.blueGray100,
                width: 1.h,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildCategories(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Categories",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 18.v),
          Wrap(
            runSpacing: 8.v,
            spacing: 8.h,
            children: List<Widget>.generate(
                8, (index) => ChipviewdevelopItemWidget()),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSalaryRange(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 16.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Salary Range",
            style: theme.textTheme.titleMedium,
          ),
          SizedBox(height: 19.v),
          Text(
            "KD400 - KD800",
            style: CustomTextStyles.bodyMediumBlack9000115,
          ),
          SizedBox(height: 11.v),
          Text(
            "The average salary is KD200",
            style: CustomTextStyles.bodyMediumBluegray400,
          ),
          SizedBox(height: 16.v),
          Card(
            clipBehavior: Clip.antiAlias,
            elevation: 0,
            margin: EdgeInsets.all(0),
            color: appTheme.gray400,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadiusStyle.roundedBorder1,
            ),
            child: Container(
              height: 75.v,
              width: 343.h,
              decoration: AppDecoration.fillGray.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder1,
              ),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgGraphic,
                    height: 60.v,
                    width: 135.h,
                    alignment: Alignment.topLeft,
                    margin: EdgeInsets.only(left: 49.h),
                  ),
                  SliderTheme(
                    data: SliderThemeData(
                      trackShape: RoundedRectSliderTrackShape(),
                      activeTrackColor: appTheme.blue700,
                      inactiveTrackColor: appTheme.gray400,
                      thumbColor:
                          theme.colorScheme.primaryContainer.withOpacity(1),
                      thumbShape: RoundSliderThumbShape(),
                    ),
                    child: RangeSlider(
                      values: RangeValues(
                        0,
                        0,
                      ),
                      min: 0.0,
                      max: 100.0,
                      onChanged: (value) {},
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildChipViewEntry(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(left: 16.h),
        child: Wrap(
          runSpacing: 8.v,
          spacing: 8.h,
          children:
              List<Widget>.generate(3, (index) => ChipviewentryItemWidget()),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRowone(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.h),
      decoration: AppDecoration.outlineGray400.copyWith(
        borderRadius: BorderRadiusStyle.circleBorder16,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          CustomPhoneNumber(
            country: selectedCountry,
            controller: phoneNumberController,
            onTap: (Country value) {
              selectedCountry = value;
            },
          ),
          Padding(
            padding: EdgeInsets.only(left: 22.h),
            child: SizedBox(
              height: 29.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
                color: appTheme.gray400,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 23.h,
              top: 5.v,
              bottom: 7.v,
            ),
            child: Text(
              "3",
              style: CustomTextStyles.labelLargeSemiBold,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgSignalOrange500,
            height: 10.adaptSize,
            width: 10.adaptSize,
            margin: EdgeInsets.only(
              left: 4.h,
              top: 10.v,
              bottom: 9.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 21.h),
            child: SizedBox(
              height: 29.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
                color: appTheme.gray400,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 23.h,
              top: 5.v,
              bottom: 7.v,
            ),
            child: Text(
              "4",
              style: CustomTextStyles.labelLargeSemiBold,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgSignalOrange500,
            height: 10.adaptSize,
            width: 10.adaptSize,
            margin: EdgeInsets.only(
              left: 5.h,
              top: 10.v,
              bottom: 9.v,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 21.h),
            child: SizedBox(
              height: 29.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
                color: appTheme.gray400,
              ),
            ),
          ),
          SizedBox(
            height: 29.v,
            child: VerticalDivider(
              width: 1.h,
              thickness: 1.v,
              color: appTheme.gray400,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 24.h,
              top: 5.v,
              bottom: 7.v,
            ),
            child: Text(
              "5",
              style: CustomTextStyles.labelLargeSemiBold,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgSignalOrange500,
            height: 10.adaptSize,
            width: 10.adaptSize,
            margin: EdgeInsets.only(
              left: 5.h,
              top: 10.v,
              bottom: 9.v,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildApplyFilters(BuildContext context) {
    return CustomElevatedButton(
      height: 82.v,
      text: "Apply Filters",
      margin: EdgeInsets.only(bottom: 34.v),
      buttonStyle: CustomButtonStyles.outlineBlueGray,
      buttonTextStyle: CustomTextStyles.titleMediumPrimaryContainer,
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
