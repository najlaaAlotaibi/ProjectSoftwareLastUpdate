import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class LoginErrorPasswordScreen extends StatelessWidget {
  LoginErrorPasswordScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController password1Controller = TextEditingController();

  bool rememberMe = false;

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.blue200,
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  children: [
                    _buildStackIphoneStatus(context),
                    SizedBox(height: 13.v),
                    Text(
                      "Sign in to your account",
                      style: theme.textTheme.titleLarge,
                    ),
                    SizedBox(height: 23.v),
                    _buildColumnEmail(context),
                    SizedBox(height: 12.v),
                    _buildColumnPassword(context),
                    SizedBox(height: 9.v),
                    _buildPassword(context),
                    SizedBox(height: 8.v),
                    _buildRowRememberMe(context),
                    SizedBox(height: 32.v),
                    _buildSignIn(context),
                    SizedBox(height: 30.v),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            top: 6.v,
                            bottom: 10.v,
                          ),
                          child: SizedBox(
                            width: 60.h,
                            child: Divider(
                              color: appTheme.gray40001,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 27.h),
                          child: Text(
                            "or",
                            style: CustomTextStyles
                                .bodyMediumMontserratBlack90001Light,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            top: 6.v,
                            bottom: 10.v,
                          ),
                          child: SizedBox(
                            width: 86.h,
                            child: Divider(
                              color: appTheme.gray40001,
                              indent: 26.h,
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 33.v),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 48.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildFacebook(context),
                          _buildGoogle(context)
                        ],
                      ),
                    ),
                    SizedBox(height: 24.v),
                    GestureDetector(
                      onTap: () {
                        onTapTxtDonthaveaaccount(context);
                      },
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Don’t have a account?",
                              style: CustomTextStyles
                                  .bodyMediumMontserratBlack90001,
                            ),
                            TextSpan(
                              text: " ",
                            ),
                            TextSpan(
                              text: "Register",
                              style: CustomTextStyles
                                  .titleSmallMontserratBluegray800,
                            )
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    SizedBox(height: 5.v)
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildSignInAs(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildStackIphoneStatus(BuildContext context) {
    return SizedBox(
      height: 213.v,
      width: 357.h,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgIphoneStatus31,
            height: 44.v,
            width: 339.h,
            alignment: Alignment.topRight,
            margin: EdgeInsets.only(top: 3.v),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgEllipse21,
            height: 104.v,
            width: 75.h,
            alignment: Alignment.topLeft,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgJobHuntingRemovebgPreview,
            height: 175.v,
            width: 273.h,
            alignment: Alignment.bottomCenter,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnEmail(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 16.h),
      padding: EdgeInsets.symmetric(horizontal: 3.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 32.h),
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "Email ",
                    style: CustomTextStyles.titleSmallMontserrat,
                  ),
                  TextSpan(
                    text: "*",
                    style: CustomTextStyles.titleSmallMontserratDeeporange500,
                  )
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          SizedBox(height: 5.v),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: CustomTextFormField(
              controller: emailController,
              hintText: "example@yourdomain.com",
              textInputType: TextInputType.emailAddress,
              suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 19.v, 16.h, 19.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgEmail51,
                  height: 16.adaptSize,
                  width: 16.adaptSize,
                ),
              ),
              suffixConstraints: BoxConstraints(
                maxHeight: 54.v,
              ),
              contentPadding: EdgeInsets.only(
                left: 16.h,
                top: 18.v,
                bottom: 18.v,
              ),
              borderDecoration: TextFormFieldStyleHelper.fillGrayF,
              fillColor: appTheme.gray1007f,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnPassword(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 16.h),
      padding: EdgeInsets.symmetric(horizontal: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 34.h),
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "Password",
                    style: CustomTextStyles.titleSmallMontserrat,
                  ),
                  TextSpan(
                    text: "*",
                    style: CustomTextStyles.titleSmallMontserratDeeporange500,
                  )
                ],
              ),
              textAlign: TextAlign.left,
            ),
          ),
          SizedBox(height: 5.v),
          Padding(
            padding: EdgeInsets.only(left: 18.h),
            child: CustomTextFormField(
              controller: passwordController,
              hintText: "***********",
              textInputType: TextInputType.visiblePassword,
              alignment: Alignment.centerRight,
              suffix: Container(
                margin: EdgeInsets.fromLTRB(30.h, 21.v, 12.h, 9.v),
                child: CustomImageView(
                  imagePath: ImageConstant.imgEye1,
                  height: 24.adaptSize,
                  width: 24.adaptSize,
                ),
              ),
              suffixConstraints: BoxConstraints(
                maxHeight: 54.v,
              ),
              obscureText: true,
              contentPadding: EdgeInsets.only(
                left: 17.h,
                top: 18.v,
                bottom: 18.v,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 21.h),
      child: CustomTextFormField(
        controller: password1Controller,
        hintText: "Password does not match email",
        hintStyle: CustomTextStyles.bodySmallMontserratSecondaryContainer,
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.emailAddress,
        prefix: Container(
          margin: EdgeInsets.fromLTRB(7.h, 6.v, 3.h, 5.v),
          child: CustomImageView(
            imagePath: ImageConstant.imgInfo21,
            height: 10.adaptSize,
            width: 10.adaptSize,
          ),
        ),
        prefixConstraints: BoxConstraints(
          maxHeight: 21.v,
        ),
        obscureText: true,
        contentPadding: EdgeInsets.only(
          top: 4.v,
          right: 20.h,
          bottom: 4.v,
        ),
        borderDecoration: TextFormFieldStyleHelper.fillRed,
        fillColor: appTheme.red50,
      ),
    );
  }

  /// Section Widget
  Widget _buildRowRememberMe(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 28.h,
        right: 16.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(bottom: 1.v),
            child: CustomCheckboxButton(
              text: "Remember me",
              value: rememberMe,
              onChange: (value) {
                rememberMe = value;
              },
            ),
          ),
          Text(
            "Forgot your Password?",
            style: CustomTextStyles.bodySmallMontserratBluegray800,
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSignIn(BuildContext context) {
    return CustomElevatedButton(
      height: 52.v,
      text: "Sign In",
      margin: EdgeInsets.only(
        left: 20.h,
        right: 19.h,
      ),
      buttonStyle: CustomButtonStyles.fillPrimaryTL7,
      buttonTextStyle: CustomTextStyles.titleMediumMontserratPrimaryContainer,
      onPressed: () {
        onTapSignIn(context);
      },
    );
  }

  /// Section Widget
  Widget _buildFacebook(BuildContext context) {
    return CustomElevatedButton(
      height: 37.v,
      width: 131.h,
      text: "Facebook",
      buttonStyle: CustomButtonStyles.fillBlueGray,
      buttonTextStyle: CustomTextStyles.bodySmallMontserratPrimaryContainer,
    );
  }

  /// Section Widget
  Widget _buildGoogle(BuildContext context) {
    return CustomElevatedButton(
      height: 37.v,
      width: 131.h,
      text: "Google",
      margin: EdgeInsets.only(left: 16.h),
      leftIcon: Container(
        margin: EdgeInsets.only(right: 7.h),
        child: CustomImageView(
          imagePath: ImageConstant.imgGoogle11,
          height: 12.adaptSize,
          width: 12.adaptSize,
        ),
      ),
      buttonStyle: CustomButtonStyles.fillGray,
      buttonTextStyle: CustomTextStyles.bodySmallMontserratGray40003,
    );
  }

  /// Section Widget
  Widget _buildSignInAs(BuildContext context) {
    return CustomOutlinedButton(
      height: 23.v,
      width: 147.h,
      text: "sign in as guest",
      margin: EdgeInsets.only(
        left: 115.h,
        right: 113.h,
        bottom: 23.v,
      ),
      leftIcon: Container(
        margin: EdgeInsets.only(right: 2.h),
        child: CustomImageView(
          imagePath: ImageConstant.imgLockBlack90001,
          height: 18.v,
          width: 19.h,
        ),
      ),
      buttonTextStyle: CustomTextStyles.bodyMediumMontserratBlack9000114,
      onPressed: () {
        onTapSignInAs(context);
      },
    );
  }

  /// Navigates to the browseOneContainerScreen when the action is triggered.
  onTapSignIn(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.browseOneContainerScreen);
  }

  /// Navigates to the signUpScreen when the action is triggered.
  onTapTxtDonthaveaaccount(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signUpScreen);
  }

  /// Navigates to the browseOneContainerScreen when the action is triggered.
  onTapSignInAs(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.browseOneContainerScreen);
  }
}
