import 'package:flutter/material.dart';

import '../../core/app_export.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.blue200,
        body: GestureDetector(
          onTap: () {
            Navigator.of(context).pushNamed(AppRoutes.getStartedScreen);
          },
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(horizontal: 44.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 6.v),
                Text(
                  "For Work",
                  textAlign: TextAlign.center,
                  style: theme.textTheme.displayLarge,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
