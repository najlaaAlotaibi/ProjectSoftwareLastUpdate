import 'package:another_stepper/dto/stepper_data.dart';
import 'package:another_stepper/widgets/another_stepper.dart';
import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class JobPreferencesScreen extends StatelessWidget {
  JobPreferencesScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController artdirectorController = TextEditingController();

  List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

  TextEditingController groupsixtyeightController = TextEditingController();

  TextEditingController groupseventyController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 32.h,
            vertical: 16.v,
          ),
          child: Column(
            children: [
              AnotherStepper(
                stepperDirection: Axis.horizontal,
                activeIndex: 4,
                barThickness: 1,
                inverted: true,
                stepperList: [
                  StepperData(),
                  StepperData(),
                  StepperData(),
                  StepperData(),
                  StepperData()
                ],
              ),
              SizedBox(height: 26.v),
              _buildList01(context),
              SizedBox(height: 18.v),
              _buildList02(context),
              SizedBox(height: 16.v),
              _buildRowMin(context),
              SizedBox(height: 5.v)
            ],
          ),
        ),
        bottomNavigationBar: _buildNext(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 21.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(
          left: 9.h,
          top: 11.v,
          bottom: 12.v,
        ),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarSubtitleTwo(
        text: "Job Preferences",
      ),
      actions: [
        AppbarSubtitleOne(
          text: "Save",
          margin: EdgeInsets.fromLTRB(16.h, 10.v, 16.h, 13.v),
        )
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildList01(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Job Categories",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 7.v),
        CustomTextFormField(
          controller: artdirectorController,
          hintText: "Art Director",
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildList02(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Pay Day",
          style: CustomTextStyles.titleMediumSemiBold,
        ),
        SizedBox(height: 7.v),
        CustomDropDown(
          icon: Container(
            margin: EdgeInsets.symmetric(horizontal: 16.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgArrowdown,
              height: 6.v,
              width: 10.h,
            ),
          ),
          hintText: "Once a Month",
          items: dropdownItemList,
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildRowMin(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: 8.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Min",
                  style: CustomTextStyles.titleMediumSemiBold,
                ),
                SizedBox(height: 9.v),
                CustomTextFormField(
                  width: 147.h,
                  controller: groupsixtyeightController,
                  hintText: "KD400",
                )
              ],
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Max",
                  style: CustomTextStyles.titleMediumSemiBold,
                ),
                SizedBox(height: 8.v),
                CustomTextFormField(
                  width: 147.h,
                  controller: groupseventyController,
                  hintText: "KD1500",
                  textInputAction: TextInputAction.done,
                )
              ],
            ),
          ),
        )
      ],
    );
  }

  /// Section Widget
  Widget _buildNext(BuildContext context) {
    return CustomElevatedButton(
      text: "Next",
      margin: EdgeInsets.only(
        left: 32.h,
        right: 32.h,
        bottom: 50.v,
      ),
      buttonTextStyle: theme.textTheme.headlineSmall!,
      onPressed: () {
        Navigator.pushNamed(context, AppRoutes.categoriesScreen);
      },
    );
  }

  /// Navigates back to the previous screen.
  onTapArrowleftone(BuildContext context) {
    Navigator.pop(context);
  }
}
